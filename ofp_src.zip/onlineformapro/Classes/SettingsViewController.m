//
//  SettingsViewController.m
//  onlineformapro
//
//  Created by Stephan on 04.03.09.
//  Copyright 2009 Coriolis Technologies. All rights reserved.
//

#import "SettingsViewController.h"
#import "LoginViewController.h"

@implementation SettingsViewController

@synthesize showAnswers;
@synthesize soundVolume;
@synthesize playSounds;

- (void)viewDidLoad
{
	[showAnswers setOn:[[NSUserDefaults standardUserDefaults] boolForKey:kPREF_SHOWANSWERS]];
	[playSounds setOn:[[NSUserDefaults standardUserDefaults] boolForKey:kPREF_PLAYSOUND]];
	[soundVolume setValue:[[NSUserDefaults standardUserDefaults] floatForKey:kPREF_SOUNDVOLUME]];
	[super viewDidLoad];
}

//==========================================================================================
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
	// Return YES for supported orientations
	return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

//==========================================================================================
- (void)didReceiveMemoryWarning
{
	[super didReceiveMemoryWarning]; // Releases the view if it doesn't have a superview
	// Release anything that's not essential, such as cached data
}

//==========================================================================================
- (void)dealloc
{
	[showAnswers release];
	[soundVolume release];
	[playSounds release];
	[super dealloc];
}

//==========================================================================================
- (IBAction) displayCompteSettings:(id)sender
{
	LoginViewController *viewController = [[LoginViewController alloc] initWithNibName:@"LoginViewController" bundle:nil];
//	[UIView beginAnimations:nil context:NULL];
//	[UIView setAnimationDuration: 0.5f];
//	[UIView setAnimationTransition:UIViewAnimationTransitionFlipFromLeft forView:self.view cache:NO];
	[self presentModalViewController:viewController animated:YES];
//	[UIView commitAnimations];
	[viewController release];
}

//==========================================================================================
- (IBAction) doneWithSettings:(id)sender
{
	NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
	[defaults setBool:[showAnswers isOn] forKey:kPREF_SHOWANSWERS];
	[defaults setBool:[playSounds isOn] forKey:kPREF_PLAYSOUND];
	[defaults setFloat:[soundVolume value] forKey:kPREF_SOUNDVOLUME];
	[defaults synchronize];
	[self.parentViewController dismissModalViewControllerAnimated:YES];
}


@end
