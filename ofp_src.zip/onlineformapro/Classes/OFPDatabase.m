//
//  OFPDatabase.m
//  onlineformapro
//
//  Created by Stephan on 09.12.08.
//  Copyright 2008 Coriolis Technologies. All rights reserved.
//

#import "OFPDatabase.h"


@implementation OFPDatabase

@synthesize dbVersion;
@synthesize ofp_DB;

static OFPDatabase *sharedOFPDatabase = nil;

#pragma mark ---- singleton object methods ----

//==========================================================================================
+ (OFPDatabase *) sharedInstance
{
	@synchronized(self) {
		if (sharedOFPDatabase == nil) {
			[[self alloc] init]; // assignment not done here
		}
	}
	return sharedOFPDatabase;
}

//==========================================================================================
+ (id)allocWithZone:(NSZone *)zone
{
	@synchronized(self) {
		if (sharedOFPDatabase == nil) {
			sharedOFPDatabase = [super allocWithZone:zone];
			return sharedOFPDatabase;  // assignment and return on first allocation
		}
	}
	return nil; // on subsequent allocation attempts return nil
}

//==========================================================================================
- (id)copyWithZone:(NSZone *)zone
{
	return self;
}

//==========================================================================================
- (id)retain
{
	return self;
}

//==========================================================================================
- (unsigned)retainCount
{
	return UINT_MAX;  // denotes an object that cannot be released
}

//==========================================================================================
- (void)release
{
	//do nothing
}

// Make Clang happy
//==========================================================================================
- (void) dealloc
{
	[super dealloc];
}

//==========================================================================================
- (id)autorelease
{
	return self;
}

//==========================================================================================
- (id)init
{
	self = [super init];
	if (self != nil) {
		BOOL success;
		NSFileManager *fileManager = [NSFileManager defaultManager];
		NSError *error;
		NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
		NSString *documentsDirectory = [paths objectAtIndex:0];
		NSString *dbPath = [documentsDirectory stringByAppendingPathComponent:@"ofpro.sqlite"];
		success = [fileManager fileExistsAtPath:dbPath];
		if (!success) {
			CMLog(@"Creating default database");
			// The writable database does not exist, so copy the default to the appropriate location.
			NSString *defaultDBPath = [[[NSBundle mainBundle] resourcePath] stringByAppendingPathComponent:@"ofpro_src.sqlite"];
			success = [fileManager copyItemAtPath:defaultDBPath toPath:dbPath error:&error];
			if (!success) {
				NSAssert1(0, @"Failed to create writable database file with message '%@'.", [error localizedDescription]);
			}
		}

		ofp_DB = [[FMDatabase alloc] initWithPath:dbPath];
		// Open the database. The database was prepared outside the application.
		if (![ofp_DB open]) {
			CMLog(@"Failed to open the database");
			// Even though the open failed, call close to properly clean up resources.
			[ofp_DB close];
			// Additional error handling, as appropriate...
		} else {
			[ofp_DB executeUpdate:@"PRAGMA cache_size=5"];
			FMResultSet *rs = [ofp_DB executeQuery:@"select db_vers from version"];
			if (rs && [rs next]) {
				self.dbVersion = [rs intForColumnIndex:0];
				[rs close];
			}
#if DEBUG==1
			[ofp_DB setLogsErrors:TRUE];
//			[ofp_DB setTraceExecution:TRUE];
#endif
		}
	}
	
	return self;
}

//==========================================================================================
- (void) vacuum
{
	MARK;
	START_TIMER;
//	[ofp_DB executeUpdate:@"VACUUM;"];
	[ofp_DB executeUpdate:@"ANALYZE;"];
	END_TIMER(@"vacuum");
}

@end
