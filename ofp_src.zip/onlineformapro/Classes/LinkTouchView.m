//
//  LinkTouchView.m
//  Liaisons
//
//  Created by Stephan on 09.03.09.
//  Copyright 2009 Coriolis Technologies. All rights reserved.
//

#import "LinkTouchView.h"


@implementation LinkTouchView

@synthesize loc1;
@synthesize loc2;
@synthesize spot_src, spot_dst;
@synthesize isMoving;
@synthesize dotimage;
@synthesize drawingColor;

//==========================================================================================
- (id) initWithQuestionCount:(int)count
{
	if ([self initWithFrame:CGRectZero]) {
		self.dotimage = [UIImage imageNamed:@"orange_dot.png"];
		self.opaque = TRUE;
		self.alpha = 1.0f;
		self.backgroundColor = [UIColor clearColor];
		self.userInteractionEnabled = YES;
		CGFloat fillColor[4] = {255.0f/255.0f, 124.0f/255.0f, 0.0f/255.0f, 1.0f};
		CGColorSpaceRef colorSpace = CGColorSpaceCreateDeviceRGB();
		drawingColor = CGColorCreate(colorSpace, fillColor);
		CFRelease(colorSpace);
		int index = 0;
		NSMutableArray *temp_array = [NSMutableArray arrayWithCapacity:5];
		for (index = 1; index <= count; index++) {
			CGRect rect = CGRectMake(108, 30+58*(index-1), 30, 30);
			Spot *spot = [[Spot alloc] init];
			spot.frame = rect;
			spot.center = CGPointMake(CGRectGetMidX(rect), CGRectGetMidY(rect));
			CMLog(@"Center of %@ is %@", NSStringFromCGRect(rect), NSStringFromCGPoint(spot.center));
			spot.brother = nil;
			[temp_array addObject:spot];
			[spot release];
		}
		left_spots = [[NSMutableArray arrayWithArray:temp_array] retain];
		
		temp_array = [NSMutableArray arrayWithCapacity:5];
		for (index = 1; index <= count; index++) {
			CGRect rect = CGRectMake(182,30+58*(index-1), 30, 30);
			Spot *spot = [[Spot alloc] init];
			spot.frame = rect;
			spot.center = CGPointMake(CGRectGetMidX(rect), CGRectGetMidY(rect));
			spot.brother = nil;
			[temp_array addObject:spot];
			[spot release];
		}
		right_spots = [[NSMutableArray arrayWithArray:temp_array] retain];
	}
	return self;
}

//==========================================================================================
- (BOOL) isMultipleTouchEnabled
{
	return NO;
}

//==========================================================================================
- (void) touchesBegan:(NSSet*)touches withEvent:(UIEvent*)event
{
	NSArray *allTouches = [touches allObjects];
	int count = [allTouches count];
	if (count > 0) {
		self.spot_src = [self spotAtPoint:[[allTouches objectAtIndex:0] locationInView:self] fuzzy:YES];
		if (self.spot_src) {
			[self unlinkSpot:spot_src];
			self.loc1 = self.spot_src.center;
			self.loc2 = self.loc1;
			isMoving = TRUE;
		}
	}
	if (count > 1) self.loc2 = [[allTouches objectAtIndex:1] locationInView:self];
	[self setNeedsDisplay];
}

//==========================================================================================
- (void) touchesMoved:(NSSet*)touches withEvent:(UIEvent*)event
{
	if (isMoving) {
		NSArray *allTouches = [touches allObjects];
		int count = [allTouches count];
		if (count > 0) {
			Spot *tmp = [self spotAtPoint:[[allTouches objectAtIndex:0] locationInView:self] fuzzy:YES];
			if (tmp && [self canLink:spot_src with:tmp]) {
				self.loc2 = tmp.center;
			} else {
				self.loc2 = [[allTouches objectAtIndex:0] locationInView:self];
			}
			[self setNeedsDisplay];
		}
	}
}

//==========================================================================================
- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
	isMoving = FALSE;
	NSArray *allTouches = [touches allObjects];
	int count = [allTouches count];
	if (count > 0) {
		Spot *tmp = [self spotAtPoint:[[allTouches objectAtIndex:0] locationInView:self] fuzzy:YES];
		if (tmp && [self canLink:spot_src with:tmp]) {
			[self linkSpot:spot_src withSpot:tmp];
		}
		[self setNeedsDisplay];
	}
	CMLog(@"Answer: %@", [self answerAsString]);
}

//==========================================================================================
- (void) drawLinkBetween:(Spot *)srcSpot brother:(Spot *)dstSpot;
{
	CGContextRef context = UIGraphicsGetCurrentContext();
	
	CGPoint point1 = srcSpot.center;
	CGPoint point2 = dstSpot.center;
	
	CGContextSetLineWidth(context, 3.0f);
	//	CGFloat fillColor[4] = {255.0f/255.0f, 124.0f/255.0f, 0.0f/255.0f, 1.0f};
	CGContextSetFillColorWithColor(context, drawingColor);
	CGContextSetStrokeColorWithColor(context, drawingColor);
	
	// Draw a line between the two location points
	CGContextMoveToPoint(context, point1.x, point1.y);
	CGContextAddLineToPoint(context, point2.x, point2.y);
	CGContextStrokePath(context);
	
	CGRect p1box = CGRectMake(point1.x, point1.y, 25.0f, 25.0f);
	CGRect p2box = CGRectMake(point2.x, point2.y, 25.0f, 25.0f);
	
	p1box = CGRectOffset(p1box, -13.0f, -12.0f);
	p2box = CGRectOffset(p2box, -13.0f, -12.0f);
	
	[dotimage drawInRect:p1box];
	[dotimage drawInRect:p2box];
	
	/*
	 // circle point 1
	 CGMutablePathRef path = CGPathCreateMutable();
	 CGPathAddEllipseInRect(path, NULL, CGRectOffset(p1box, 3.0f, 3.0f));
	 CGContextAddPath(context, path);
	 CGContextSetFillColor(context, shadowColor);
	 CGContextFillPath(context);
	 CFRelease(path);
	 CGPathAddEllipseInRect(path, NULL, p1box);
	 CGContextAddPath(context, path);
	 CGContextFillPath(context);
	 CFRelease(path);
	 
	 // circle point 2
	 path = CGPathCreateMutable();
	 CGPathAddEllipseInRect(path, NULL, p2box);
	 CGContextAddPath(context, path);
	 CGContextFillPath(context);	
	 CFRelease(path);
	 */
}

//==========================================================================================
- (BOOL) canLink:(Spot *)spot1 with:(Spot *)spot2
{
	NSArray *array = right_spots;
	if ([left_spots containsObject:spot1])
		array = left_spots;
	
	if ([array containsObject:spot2]) 
		return FALSE;
	return TRUE;
}

//==========================================================================================
- (Spot *) spotAtPoint:(CGPoint)touchePoint fuzzy:(BOOL)fuzzy
{
	Spot *foundSpot;
	
	for (Spot *spot in left_spots) {
		CGRect frame = spot.frame;
		if (fuzzy) {
			frame = CGRectInset(spot.frame, -20.0f, -20.0f);
		}
		if (CGRectContainsPoint(frame, touchePoint)) {
			foundSpot = spot;
			return foundSpot;
		}
	}
	for (Spot *spot in right_spots) {
		CGRect frame = spot.frame;
		if (fuzzy) {
			frame = CGRectInset(spot.frame, -20.0f, -20.0f);
		}
		if (CGRectContainsPoint(frame, touchePoint)) {
			foundSpot = spot;
			return foundSpot;
		}
	}
	return NULL;
}
//==========================================================================================
- (void) unlinkSpot:(Spot *)spot
{
	if (spot.brother != NULL) {
		spot.brother.brother = nil;
		spot.brother = nil;
	}
}

//==========================================================================================
- (void) displayValidAnswer:(NSString *)answer
{
	self.dotimage = [UIImage imageNamed:@"green_dot.png"];
	self.userInteractionEnabled = NO;
	CFRelease(drawingColor);
	CGFloat fillColor[4] = {1.0f/255.0f, 128.0f/255.0f, 64.0f/255.0f, 1.0f};
	CGColorSpaceRef colorSpace = CGColorSpaceCreateDeviceRGB();
	drawingColor = CGColorCreate(colorSpace, fillColor);
	CFRelease(colorSpace);
	
	NSArray *answerList = [answer componentsSeparatedByString:@"*^*"];
	for (Spot *spot in left_spots) {
		[self unlinkSpot:spot];
	}
	int leftPos;
	int rightPos;
	for (NSString *answer in answerList) {
		NSArray *spotArray = [answer componentsSeparatedByString:@"_"];
		NSMutableString *spot1 = [NSMutableString stringWithString:[spotArray objectAtIndex:0]];
		NSMutableString *spot2 = [NSMutableString stringWithString:[spotArray objectAtIndex:1]];
		leftPos = -1;
		rightPos = -1;
		if ([spot1 characterAtIndex:0] == 'G') {
			[spot1 deleteCharactersInRange:NSMakeRange(0, 1)];
			leftPos = [spot1 intValue];
		} else {
			[spot1 deleteCharactersInRange:NSMakeRange(0, 1)];
			rightPos = [spot1 intValue];
		}
		if ([spot2 characterAtIndex:0] == 'G') {
			[spot2 deleteCharactersInRange:NSMakeRange(0, 1)];
			leftPos = [spot2 intValue];
		} else {
			[spot2 deleteCharactersInRange:NSMakeRange(0, 1)];
			rightPos = [spot2 intValue];
		}
		if ((leftPos != -1) && (rightPos != -1)) {
			[self linkSpot:[left_spots objectAtIndex:leftPos] withSpot:[right_spots objectAtIndex:rightPos]];
		}
	}
	[self setNeedsDisplay];
}

//==========================================================================================
- (NSString *) answerAsString
{
	NSMutableString *resultString = [NSMutableString string];
	for (Spot *spot in left_spots) {
		if (spot.brother) {
			[resultString appendFormat:@"G%d_D%d*^*", [left_spots indexOfObject:spot], [right_spots indexOfObject:spot.brother]];
		}
	}
	if ([resultString length] > 3)
		[resultString deleteCharactersInRange:NSMakeRange([resultString length]-3, 3)];
	return resultString;
}
//==========================================================================================
- (void) linkSpot:(Spot *)spot1 withSpot:(Spot *)spot2
{
	[self unlinkSpot:spot1];
	[self unlinkSpot:spot2];
	spot1.brother = spot2;
	spot2.brother = spot1;
}

//==========================================================================================
- (void) drawRect: (CGRect) aRect
{
	// Get the current context
	CGContextRef context = UIGraphicsGetCurrentContext();
	CGContextClearRect(context, aRect);
	
	for (Spot *spot in left_spots) {
		if (spot.brother) {
			[self drawLinkBetween:spot brother:spot.brother];
		}
	}
	
	if (isMoving) {
		// Set up the stroke and fill characteristics
		CGContextSetLineWidth(context, 3.0f);
		//		CGFloat fillColor[4] = {255.0f/255.0f, 124.0f/255.0f, 0.0f/255.0f, 1.0f};
		CGContextSetFillColorWithColor(context, drawingColor);
		CGContextSetStrokeColorWithColor(context, drawingColor);
		
		// Draw a line between the two location points
		CGContextMoveToPoint(context, self.loc1.x, self.loc1.y);
		CGContextAddLineToPoint(context, self.loc2.x, self.loc2.y);
		CGContextStrokePath(context);
		
		CGRect p1box = CGRectMake(self.loc1.x, self.loc1.y, 25.0f, 25.0f);
		CGRect p2box = CGRectMake(self.loc2.x, self.loc2.y, 25.0f, 25.0f);
		
		p1box = CGRectOffset(p1box, -13.0f, -12.0f);
		p2box = CGRectOffset(p2box, -13.0f, -12.0f);
		
		[dotimage drawInRect:p1box];
		[dotimage drawInRect:p2box];
		
		/*		
		 // circle point 1
		 CGMutablePathRef path = CGPathCreateMutable();
		 CGPathAddEllipseInRect(path, NULL, CGRectInset(p1box, offset, offset));
		 CGContextAddPath(context, path);
		 CGContextFillPath(context);
		 CFRelease(path);
		 
		 // circle point 2
		 path = CGPathCreateMutable();
		 CGPathAddEllipseInRect(path, NULL, CGRectInset(p2box, offset, offset));
		 CGContextAddPath(context, path);
		 CGContextFillPath(context);	
		 CFRelease(path);
		 */
	}
	
}

//==========================================================================================
- (void) dealloc
{
	[spot_src release];
	[spot_dst release];
	CFRelease(drawingColor);
	[left_spots release];
	[right_spots release];
	[dotimage release];
	[super dealloc];
}

@end
