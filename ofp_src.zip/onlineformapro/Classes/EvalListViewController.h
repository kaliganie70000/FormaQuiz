//
//  EvalListViewController.h
//  onlineformapro
//
//  Created by Stephan on 05.03.09.
//  Copyright 2009 Coriolis Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface EvalListViewController : UIViewController {
	
	IBOutlet UITableView *tableView;
	IBOutlet UILabel *sousThemeLabel;
	NSIndexPath *selectedIndexPath;
	NSArray *evalList;
	NSString *themeTitle;
	NSString *sousThemeTitle;
}

@property (nonatomic, retain) UITableView *tableView;
@property (nonatomic, retain) UILabel *sousThemeLabel;
@property (nonatomic, retain) NSIndexPath *selectedIndexPath;
@property (nonatomic, retain) NSArray	*evalList;
@property (nonatomic, copy) NSString *themeTitle;
@property (nonatomic, copy) NSString *sousThemeTitle;

@end