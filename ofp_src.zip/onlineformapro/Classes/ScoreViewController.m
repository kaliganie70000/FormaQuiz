//
//  ScoreViewController.m
//  onlineformapro
//
//  Created by Stephan on 07.03.09.
//  Copyright 2009 Coriolis Technologies. All rights reserved.
//

#import "ScoreViewController.h"
#import "Reachability.h"
#import "onlineformaproAppDelegate.h"

@implementation ScoreViewController

@synthesize scoreLabel;
@synthesize progressView;
@synthesize score;

//==========================================================================================
- (IBAction) restart:(id)sender
{
	[UIView beginAnimations:nil context:NULL];
	[UIView setAnimationDuration: 0.5f];
	[UIView setAnimationTransition:UIViewAnimationTransitionFlipFromRight forView:self.navigationController.view cache:NO];
	[self.navigationController popToRootViewControllerAnimated:NO];
	[UIView commitAnimations];
}

//==========================================================================================
- (void) viewWillAppear:(BOOL)animated
{
	progressView.hidden = TRUE;
	scoreLabel.text = score;
	self.navigationController.navigationBarHidden = YES;
	[super viewWillAppear:animated];
}

//==========================================================================================
- (void) viewDidAppear:(BOOL) animated
{
	Reachability *reachManager = [Reachability sharedReachability];
	[reachManager setHostName:kMAIN_URL];
	NetworkStatus remoteHostStatus         = [[Reachability sharedReachability] remoteHostStatus];
	NetworkStatus internetConnectionStatus = [[Reachability sharedReachability] internetConnectionStatus];
	
	if ((internetConnectionStatus != NotReachable) || (remoteHostStatus != NotReachable)) {
		progressView.hidden = FALSE;
		[self performSelector:@selector(sendResults) withObject:nil afterDelay:0.5f];
	} else {
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Attention" message:@"Les résultats n'ont pas été transmis. Ils seront envoyés au prochain lancement du programme." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
		[alert show];
		[alert release];	
	}
	[super viewDidAppear:animated];

}

//==========================================================================================
- (void) sendResults
{
	[UIAppDelegate sendRemainingResultsToServer];
	progressView.hidden = TRUE;
}

//==========================================================================================
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
	// Return YES for supported orientations
	return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

//==========================================================================================
- (void)didReceiveMemoryWarning
{
	[super didReceiveMemoryWarning]; // Releases the view if it doesn't have a superview
	// Release anything that's not essential, such as cached data
}

//==========================================================================================
- (void)dealloc
{
	[score release];
	[scoreLabel release];
	[super dealloc];
}


@end
