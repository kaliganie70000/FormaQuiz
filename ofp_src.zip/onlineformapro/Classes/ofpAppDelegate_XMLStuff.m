//
//  ofpAppDelegate_XMLStuff.m
//  onlineformapro
//
//  Created by Stephan on 04.03.09.
//  Copyright 2009 Coriolis Technologies. All rights reserved.
//

#import "TouchXML.h"
#import "ofpAppDelegate_XMLStuff.h"


@implementation onlineformaproAppDelegate (XMLStuff)

//==========================================================================================
- (NSMutableDictionary *)parseEvaluation:(CXMLNode *)soustheme 
{
	NSMutableDictionary *dict = [NSMutableDictionary dictionary];
	[dict setObject:[[(CXMLElement *)soustheme attributeForName:@"id"] stringValue] forKey:@"id"];
	[dict setObject:[[(CXMLElement *)soustheme attributeForName:@"titre"] stringValue] forKey:@"titre"];
	for (CXMLNode *child in [soustheme children]) {
		if ([child isMemberOfClass:[CXMLElement class]]) {
			NSString *child_name = [child name];
			NSString *child_value = [child stringValue];
			if (child_value == NULL)
				child_value = @"";
			[dict setObject:child_value forKey:child_name];
		}
	}
	return dict;
}

//==========================================================================================
- (NSMutableDictionary *)parseSousTheme:(CXMLNode *)soustheme
{
	NSMutableDictionary *dict = [NSMutableDictionary dictionary];
	[dict setObject:[[(CXMLElement *)soustheme attributeForName:@"id"] stringValue] forKey:@"id"];
	[dict setObject:[[(CXMLElement *)soustheme attributeForName:@"titre"] stringValue] forKey:@"titre"];
	NSMutableArray *eval_array = [NSMutableArray array];
	for (CXMLNode *child in [soustheme children]) {
		if ([child isMemberOfClass:[CXMLElement class]]) {
			NSString *child_name = [child name];
			if ([child_name isEqualToString:@"evaluation"]) {
				NSDictionary *sub = [self parseEvaluation:child];
				[eval_array addObject:sub];
			}
			//			[resultArray addObject:dict];
		}
	}
	[dict setObject:eval_array forKey:@"evaluation"];
	return dict;
}

//==========================================================================================
- (NSMutableDictionary *)parseTheme:(CXMLNode *)theme 
{
	NSMutableDictionary *dict = [NSMutableDictionary dictionary];
	[dict setObject:[[(CXMLElement *)theme attributeForName:@"id"] stringValue] forKey:@"id"];
	[dict setObject:[[(CXMLElement *)theme attributeForName:@"titre"] stringValue] forKey:@"titre"];
	NSMutableArray *stheme_array = [NSMutableArray array];
	for (CXMLNode *child in [theme children]) {
		if ([child isMemberOfClass:[CXMLElement class]]) {
			NSString *child_name = [child name];
			if ([child_name isEqualToString:@"soustheme"]) {
				NSDictionary *sub = [self parseSousTheme:child];
				[stheme_array addObject:sub];
			}
		}
	}
	[dict setObject:stheme_array forKey:@"soustheme"];
	return dict;
}

//==========================================================================================
- (NSArray *) parseEvalListData:(NSData *)data
{
	NSError *theError = NULL;
	NSString *theXML = [[[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding] autorelease];

	CXMLDocument *theXMLDocument = [[[CXMLDocument alloc] initWithXMLString:theXML options:0 error:&theError] autorelease];
	if ((theXMLDocument == NULL) || (theError != NULL)) {
		CMLog(@"theError: %@", theError);
		return NULL;
	}

	NSArray *themes = [theXMLDocument nodesForXPath:@"/response/params/liste/theme" error:&theError];
	if ([themes count] == 0) {
		return NULL;
	}
	NSMutableArray *eval_array = [NSMutableArray array];
	for (CXMLNode *theme in themes) {
		NSDictionary *themeDict = [self parseTheme:theme];
		[eval_array addObject:themeDict];
	}

	CMLog(@"eval_array: %@", eval_array);
	return eval_array;
}

//==========================================================================================
- (NSMutableDictionary *)parseQuestion:(CXMLNode *)question
{
	NSMutableDictionary *dict = [NSMutableDictionary dictionary];
	for (CXMLNode *child in [question children]) {
		if ([child isMemberOfClass:[CXMLElement class]]) {
			NSString *child_name = [child name];
			NSString *child_value = [child stringValue];
			if (child_value == NULL)
				child_value = @"";
			[dict setObject:child_value forKey:child_name];
		}
	}
	return dict;
}

//==========================================================================================
- (void) shuffleParcours:(NSMutableArray *)question_list
{
	int i, j, n;
	
	n = [question_list count];
	for(i = n - 1; i >= 0; i--)
	{
		j = random() % n;
		if(j == i)
			continue;
		[question_list exchangeObjectAtIndex:j withObjectAtIndex:i];
	}
}

//==========================================================================================
- (NSDictionary *) parseParcoursData:(NSData *)data
{
	NSError *theError = NULL;

	if (data == NULL)
		return NULL;

	NSString *theXML = [[[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding] autorelease];
	
	CXMLDocument *theXMLDocument = [[[CXMLDocument alloc] initWithXMLString:theXML options:0 error:&theError] autorelease];
	if ((theXMLDocument == NULL) || (theError != NULL)) {
		CMLog(@"theError: %@", theError);
		return NULL;
	}
	
	NSArray *nodes = [theXMLDocument nodesForXPath:@"/parcours/@alea" error:&theError];
	if ([nodes count] == 0) {
		CMLog(@"Failed to get alea");
		return NULL;
	}
	NSString *alea = [[nodes objectAtIndex:0] stringValue];

	NSArray *questions = [theXMLDocument nodesForXPath:@"/parcours/item" error:&theError];
	if ([questions count] == 0) {
		return NULL;
	}
	
	NSMutableDictionary *parcours_dict = [NSMutableDictionary dictionary];

	for (CXMLElement *question in questions) {
		NSMutableDictionary *dict = [NSMutableDictionary dictionary];
		[dict setObject:[[question attributeForName:@"id"] stringValue] forKey:@"ordre"];
		[dict setObject:[[question attributeForName:@"coef"] stringValue] forKey:@"coef"];
		[dict setObject:[[question attributeForName:@"dif"] stringValue] forKey:@"dif"];
		[parcours_dict setObject:dict forKey:[[question attributeForName:@"id_question"] stringValue]];
	}
	
	if ([alea isEqualToString:@"true"]) {
		NSMutableArray *question_order = [NSMutableArray array];
		for (NSString *key in parcours_dict) {
			NSDictionary *dict = [parcours_dict objectForKey:key];
			[question_order addObject:[dict objectForKey:@"ordre"]];
		}
		[self shuffleParcours:question_order];
		int index = 0;
		for (NSString *key in parcours_dict) {
			NSMutableDictionary *dict = [parcours_dict objectForKey:key];
			[dict setObject:[question_order objectAtIndex:index] forKey:@"ordre"];
			index++;
		}
	}

	CMLog(@"parcours_dict: %@", parcours_dict);
	return parcours_dict;
}

//==========================================================================================
- (NSArray *) parseQuestionsListData:(NSData *)data
{
	NSError *theError = NULL;

	if (data == NULL)
		return NULL;

	NSString *theXML = [[[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding] autorelease];

	CXMLDocument *theXMLDocument = [[[CXMLDocument alloc] initWithXMLString:theXML options:0 error:&theError] autorelease];
	if ((theXMLDocument == NULL) || (theError != NULL)) {
		CMLog(@"theError: %@", theError);
		return NULL;
	}

	NSArray *questions = [theXMLDocument nodesForXPath:@"/quizz/question" error:&theError];
	if ([questions count] == 0) {
		return NULL;
	}

	NSMutableArray *question_array = [NSMutableArray array];
	for (CXMLNode *question in questions) {
		NSDictionary *questionDict = [self parseQuestion:question];
		[question_array addObject:questionDict];
	}
	
//	CMLog(@"question_array: %@", question_array);
	return question_array;
}

//==========================================================================================
- (NSDictionary *) parcoursDataForGUID:(NSString *)guid
{
	NSString *evalPath = [NSString stringWithFormat:@"%@/%@", self.documentsPath, guid];
	NSString *parcoursFilePath = [NSString stringWithFormat:@"%@/parcours.xml", evalPath];
	NSData *data = [NSData dataWithContentsOfFile:parcoursFilePath];
	return [self parseParcoursData:data];
}

//==========================================================================================
- (NSArray *) questionsListForGUID:(NSString *)guid
{
	NSDictionary *parcours_data = [self parcoursDataForGUID:guid];
	if (parcours_data == NULL)
		return NULL;

	NSString *evalPath = [NSString stringWithFormat:@"%@/%@", self.documentsPath, guid];
	NSString *questionFilePath = [NSString stringWithFormat:@"%@/questions.xml", evalPath];
	NSData *data = [NSData dataWithContentsOfFile:questionFilePath];
	NSArray *questionListArray = [self parseQuestionsListData:data];
	if ((questionListArray == NULL) || ([questionListArray count] == 0))
		return NULL;
	
	for (NSMutableDictionary *dict in questionListArray) {
		NSString *idQuestion = [dict objectForKey:@"idQuestion"];
		NSDictionary *parcours_dict = [parcours_data objectForKey:idQuestion];
		[dict setObject:[parcours_dict objectForKey:@"ordre"] forKey:@"ordre"];
		[dict setObject:[parcours_dict objectForKey:@"coef"] forKey:@"coef"];
	}
	
	CMLog(@"questionListArray: %@", questionListArray);
	NSSortDescriptor *sortDescriptor = [[[NSSortDescriptor alloc] initWithKey:@"ordre"
																																	ascending:YES
																																	 selector:@selector(compareWithNumericSearch:)] autorelease];
	
	NSArray *descriptors = [NSArray arrayWithObjects:sortDescriptor, nil];
	
	NSArray *sortedArray = [questionListArray sortedArrayUsingDescriptors:descriptors];
	CMLog(@"sortedArray: %@", sortedArray);
	return sortedArray;
}

@end
