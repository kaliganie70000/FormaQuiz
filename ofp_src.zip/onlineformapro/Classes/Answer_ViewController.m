//
//  Answer_ViewController.m
//  onlineformapro
//
//  Created by Stephan on 09.03.09.
//  Copyright 2009 Coriolis Technologies. All rights reserved.
//

#import "Answer_ViewController.h"


@implementation Answer_ViewController

@synthesize validAnswer;
@synthesize imageView;

//==========================================================================================
- (void) viewWillAppear:(BOOL)animated
{
//	self.navigationController.navigationBarHidden = YES;
}

//==========================================================================================
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
	// Return YES for supported orientations
	return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

//==========================================================================================
- (void)didReceiveMemoryWarning
{
	[super didReceiveMemoryWarning]; // Releases the view if it doesn't have a superview
	// Release anything that's not essential, such as cached data
}

//==========================================================================================
- (void)dealloc
{
	[imageView release];
	[super dealloc];
}


@end
