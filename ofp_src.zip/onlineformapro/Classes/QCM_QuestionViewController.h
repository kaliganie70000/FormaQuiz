//
//  QCM_QuestionViewController.h
//  onlineformapro
//
//  Created by Stephan on 06.03.09.
//  Copyright 2009 Coriolis Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface QCM_QuestionViewController : UIViewController {
	
	IBOutlet UIButton *answer1Button;
	IBOutlet UIButton *answer2Button;
	IBOutlet UIButton *answer3Button;
	IBOutlet UIButton *answer4Button;
	IBOutlet UIImageView *questionImageView;
	IBOutlet UILabel *answer1Label;
	IBOutlet UILabel *answer2Label;
	IBOutlet UILabel *answer3Label;
	IBOutlet UILabel *answer4Label;
	
	BOOL qcm;
	NSDictionary *question;
	NSString *evalPath;

}

@property (nonatomic, retain) UIButton *answer1Button;
@property (nonatomic, retain) UIButton *answer2Button;
@property (nonatomic, retain) UIButton *answer3Button;
@property (nonatomic, retain) UIButton *answer4Button;
@property (nonatomic, retain) UIImageView *questionImageView;
@property (nonatomic, retain) UILabel *answer1Label;
@property (nonatomic, retain) UILabel *answer2Label;
@property (nonatomic, retain) UILabel *answer3Label;
@property (nonatomic, retain) UILabel *answer4Label;
@property (nonatomic, retain) NSDictionary *question;
@property (nonatomic, copy) NSString *evalPath;
@property (nonatomic, assign) BOOL qcm;

- (IBAction) touchDown:(UIButton *)sender;
- (IBAction) buttonClicked:(id)sender;
- (NSNumber *) isAnswerValid;
- (void) displayValidAnswer;

@end
