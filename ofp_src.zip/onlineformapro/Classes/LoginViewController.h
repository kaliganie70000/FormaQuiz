//
//  LoginViewController.h
//  onlineformapro
//
//  Created by Stephan on 02.03.09.
//  Copyright 2009 Coriolis Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface LoginViewController : UIViewController <UITextFieldDelegate> {
	IBOutlet UIButton *accountTestButton;
	IBOutlet UITextField *usernameField;
	IBOutlet UITextField *passwordField;
	IBOutlet UITextField *clientIDField;
}

@property (nonatomic, retain) UIButton *accountTestButton;
@property (nonatomic, retain) UITextField *usernameField;
@property (nonatomic, retain) UITextField *passwordField;
@property (nonatomic, retain) UITextField *clientIDField;

- (IBAction) testAccount:(id)sender;
- (IBAction) doneWithAccount:(id)sender;

@end
