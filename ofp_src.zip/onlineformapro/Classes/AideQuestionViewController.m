//
//  AideQuestionViewController.m
//  onlineformapro
//
//  Created by Stephan on 06.03.09.
//  Copyright 2009 Coriolis Technologies. All rights reserved.
//

#import "AideQuestionViewController.h"


@implementation AideQuestionViewController

@synthesize aideTextView;

//==========================================================================================
- (IBAction) closeDialog:(id)sender
{
	[self.parentViewController dismissModalViewControllerAnimated:YES];
}

//==========================================================================================
- (void)viewDidLoad
{
	[super viewDidLoad];
}

//==========================================================================================
- (void) viewWillAppear:(BOOL) animated
{
	self.navigationController.navigationBarHidden = YES;
}

//==========================================================================================
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
	// Return YES for supported orientations
	return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

//==========================================================================================
- (void)didReceiveMemoryWarning
{
	[super didReceiveMemoryWarning]; // Releases the view if it doesn't have a superview
}

//==========================================================================================
- (void)dealloc
{
	[aideTextView release];
	[super dealloc];
}

@end
