//
//  Spot.m
//  Liaisons
//
//  Created by Stephan on 09.03.09.
//  Copyright 2009 Coriolis Technologies. All rights reserved.
//

#import "Spot.h"

@implementation Spot

@synthesize frame, brother, center;

@end
