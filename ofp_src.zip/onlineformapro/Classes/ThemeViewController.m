//
//  ThemeViewController.m
//  onlineformapro
//
//  Created by Stephan on 02.03.09.
//  Copyright 2009 Coriolis Technologies. All rights reserved.
//

#import "onlineformaproAppDelegate.h"
#import "ThemeViewController.h"
#import "SousThemeViewController.h"


@implementation ThemeViewController

@synthesize tableView;
@synthesize	selectedIndexPath;
@synthesize themeList;

//==========================================================================================
- (void) viewDidLoad
{
//	UINavigationItem *navItem = self.navigationItem;
//	UIBarButtonItem *goBackButtonItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemCancel target:self action:@selector(goBack)];
//	navItem.leftBarButtonItem = goBackButtonItem;
//	[goBackButtonItem release];
	self.navigationController.navigationBar.tintColor = [UIColor blackColor];
	[super viewDidLoad];
}

//==========================================================================================
- (IBAction)goBack:(id)sender
{
	[UIView beginAnimations:nil context:NULL];
	[UIView setAnimationDuration: 0.5f];
	[UIView setAnimationTransition:UIViewAnimationTransitionFlipFromRight forView:self.navigationController.view cache:NO];
	[self.navigationController popViewControllerAnimated:NO];
	[UIView commitAnimations];
}

//==========================================================================================
- (void)viewWillAppear:(BOOL)animated
{
	MARK;
	UIBarButtonItem *goBackItem = [[UIBarButtonItem alloc] initWithTitle:@"Accueil" style:UIBarButtonItemStyleBordered target:self action:@selector(goBack:)];
	UINavigationItem *navItem = self.navigationItem;
	navItem.leftBarButtonItem = goBackItem;
	[goBackItem release];

	self.themeList = [UIAppDelegate postProcessEvalList:themeList];
	self.navigationController.navigationBarHidden = NO;
	self.navigationItem.title = @"Catalogue";
	self.title = @"Catalogue";
	[self.tableView deselectRowAtIndexPath:selectedIndexPath animated:YES];
	[self.tableView reloadData];
	[super viewWillAppear:animated];
} 

//==========================================================================================
- (void)viewDidAppear:(BOOL)animated
{
	MARK;
	[super viewDidAppear:animated];
}

//==========================================================================================
- (void)viewWillDisappear:(BOOL)animated
{
	MARK;
	[super viewWillDisappear:animated];
}

//==========================================================================================
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
	// Return YES for supported orientations
	return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

//==========================================================================================
- (void)didReceiveMemoryWarning
{
	[super didReceiveMemoryWarning]; // Releases the view if it doesn't have a superview
	// Release anything that's not essential, such as cached data
}

//==========================================================================================
- (void)dealloc
{
	MARK;
	[themeList release];
	[selectedIndexPath release];
	[tableView release];
	[super dealloc];
}

//==========================================================================================
- (void) goBack
{
	[self.view removeFromSuperview];
}

//==========================================================================================
#pragma mark UITableView delegate methods
//==========================================================================================
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView 
{
	return 1;
}

//==========================================================================================
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section 
{
	return [themeList count];
}

//==========================================================================================
- (UITableViewCell *)tableView:(UITableView *)tv cellForRowAtIndexPath:(NSIndexPath *)indexPath 
{
	UITableViewCell *cell = [tv dequeueReusableCellWithIdentifier:@"themeListCell"];
	if (cell == nil) {
		cell = [[[UITableViewCell alloc] initWithFrame:CGRectZero reuseIdentifier:@"themeListCell"] autorelease];
	}

	cell.text = [[themeList objectAtIndex:indexPath.row] objectForKey:@"titre"];
	cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
	
	// Set up the cell
	return cell;
}

//==========================================================================================
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
	NSArray *sousThemeList = [[themeList objectAtIndex:indexPath.row] objectForKey:@"soustheme"];
	self.selectedIndexPath = indexPath;
	SousThemeViewController *viewController = [[SousThemeViewController alloc] initWithNibName:@"SousThemeViewController" bundle:nil];
	viewController.themeTitle = [[themeList objectAtIndex:indexPath.row] objectForKey:@"titre"];
	viewController.sousThemeList = sousThemeList;
	[self.navigationController pushViewController:viewController animated:YES];
	[viewController release];
}

@end
