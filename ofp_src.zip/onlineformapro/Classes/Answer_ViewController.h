//
//  Answer_ViewController.h
//  onlineformapro
//
//  Created by Stephan on 09.03.09.
//  Copyright 2009 Coriolis Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface Answer_ViewController : UIViewController {
	
	IBOutlet UIImageView *imageView;
	BOOL validAnswer;

}

@property (nonatomic, retain) UIImageView *imageView;
@property (nonatomic, assign) BOOL validAnswer;

@end
