//
//  DescriptifEvalViewController.h
//  onlineformapro
//
//  Created by Stephan on 05.03.09.
//  Copyright 2009 Coriolis Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface DescriptifEvalViewController : UIViewController {
	
	IBOutlet UIButton *button;
	IBOutlet UIImageView *buttonImage;
	IBOutlet UILabel *evalNameLabel;
	IBOutlet UILabel *sousThemeLabel;
	IBOutlet UILabel *descriptifLabel;
	IBOutlet UIBarButtonItem *trashButtonItem;
	IBOutlet UIView *loadingView;
	IBOutlet UIActivityIndicatorView *activityIndicator;
	IBOutlet UILabel *loadingViewLabel;
	IBOutlet UILabel *scoreLabel;
	NSMutableDictionary *evaluation;
	NSString *themeTitle;
	NSString *sousThemeTitle;	
}

@property (nonatomic, retain) UIButton *button;
@property (nonatomic, retain) UIImageView *buttonImage;
@property (nonatomic, retain) UILabel *evalNameLabel;
@property (nonatomic, retain) UILabel *sousThemeLabel;
@property (nonatomic, retain) UILabel *descriptifLabel;
@property (nonatomic, retain) UILabel *scoreLabel;
@property (nonatomic, retain) UIBarButtonItem *trashButtonItem;
@property (nonatomic, retain) NSMutableDictionary *evaluation;
@property (nonatomic, copy) NSString *themeTitle;
@property (nonatomic, retain) NSString *sousThemeTitle;

@property (nonatomic, retain) UIView *loadingView;
@property (nonatomic, retain) UIActivityIndicatorView *activityIndicator;
@property (nonatomic, retain) UILabel *loadingViewLabel;

- (IBAction) trashItem:(id)sender;
- (IBAction) buttonAction:(id)sender;
- (void) downloadEval;

@end
