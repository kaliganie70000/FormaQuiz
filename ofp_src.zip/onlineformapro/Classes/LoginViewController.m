//
//  LoginViewController.m
//  onlineformapro
//
//  Created by Stephan on 02.03.09.
//  Copyright 2009 Coriolis Technologies. All rights reserved.
//

#import "onlineformaproAppDelegate.h"
#import "LoginViewController.h"
#import "SettingsViewController.h"
#import "Reachability.h"

@implementation LoginViewController

@synthesize accountTestButton;
@synthesize usernameField;
@synthesize passwordField;
@synthesize clientIDField;

//==========================================================================================
- (void)viewDidLoad
{
	NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
	NSString *username = [defaults stringForKey:kPREF_USER];
	NSString *password = [defaults stringForKey:kPREF_PWD];
	NSString *clientID = [defaults stringForKey:kPREF_CLIENT];
	[usernameField setText: username];
	[passwordField setText: password];
	[clientIDField setText: clientID];
	[super viewDidLoad];
}

//==========================================================================================
- (void)viewDidAppear:(BOOL)animated
{
	[usernameField becomeFirstResponder];
}

//==========================================================================================
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
	// Return YES for supported orientations
	return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

//==========================================================================================
- (void)didReceiveMemoryWarning
{
	[super didReceiveMemoryWarning]; // Releases the view if it doesn't have a superview
	// Release anything that's not essential, such as cached data
}

//==========================================================================================
- (void)dealloc
{
	[accountTestButton release];
	[usernameField release];
	[passwordField release];
	[clientIDField release];
	[super dealloc];
}

//==========================================================================================
- (IBAction) testAccount:(id)sender
{
	NSString *username = [usernameField text];
	NSString *password = [passwordField text];
	NSString *clientID = [clientIDField text];

	NetworkStatus remoteHostStatus         = [[Reachability sharedReachability] remoteHostStatus];
	NetworkStatus internetConnectionStatus = [[Reachability sharedReachability] internetConnectionStatus];
	
	//	CMLog(@"internetConnectionStatus: %d, remoteHostStatus: %d", internetConnectionStatus, remoteHostStatus);
	
	if ((internetConnectionStatus != NotReachable) || (remoteHostStatus != NotReachable)) {
		[UIAppDelegate logout];
		if ([UIAppDelegate loginWithUser:username password:password client:clientID]) {
			NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
			[defaults setObject:[usernameField text] forKey:kPREF_USER];
			[defaults setObject:[passwordField text] forKey:kPREF_PWD];
			[defaults setObject:[clientIDField text] forKey:kPREF_CLIENT];
			[defaults synchronize];
			[self.parentViewController dismissModalViewControllerAnimated:YES];
		}
	} else {
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Attention" message:@"Vous devez avoir une connexion internet pour pouvoir effectuer cette opération." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
		[alert show];
		[alert release];	
	}
}

//==========================================================================================
- (IBAction) doneWithAccount:(id)sender
{
	NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
	[defaults setObject:[usernameField text] forKey:kPREF_USER];
	[defaults setObject:[passwordField text] forKey:kPREF_PWD];
	[defaults setObject:[clientIDField text] forKey:kPREF_CLIENT];
	[defaults synchronize];
	CMLog(@"self.parentViewController.class: %@", self.parentViewController.class);
	if ([self.parentViewController.class class] == [SettingsViewController class]) {
//		[UIView beginAnimations:nil context:NULL];
//		[UIView setAnimationDuration: 0.5f];
//		[UIView setAnimationTransition:UIViewAnimationTransitionFlipFromRight forView:self.navigationController.view cache:NO];
		[self.parentViewController dismissModalViewControllerAnimated:YES];
//		[UIView commitAnimations];
	} else 
		[self.parentViewController dismissModalViewControllerAnimated:YES];
}

//==========================================================================================
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
	MARK;
	if ([textField tag] == 1) {
		[usernameField resignFirstResponder];
		[passwordField becomeFirstResponder];
	}
	if ([textField tag] == 2) {
		[passwordField resignFirstResponder];
		[clientIDField becomeFirstResponder];
	}
	if ([textField tag] == 3) {
		[clientIDField resignFirstResponder];
	}
	return YES;
}

@end
