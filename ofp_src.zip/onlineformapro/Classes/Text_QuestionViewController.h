//
//  Text_QuestionViewController.h
//  onlineformapro
//
//  Created by Stephan on 07.03.09.
//  Copyright 2009 Coriolis Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface Text_QuestionViewController : UIViewController <UITextFieldDelegate> {
	IBOutlet UITextField *textField;
	IBOutlet UIImageView *questionImageView;
	IBOutlet UILabel *answerLabel;

	NSDictionary *question;
	NSString *evalPath;
}

@property (nonatomic, retain) UITextField *textField;
@property (nonatomic, retain) UIImageView *questionImageView;
@property (nonatomic, retain) UILabel *answerLabel;
@property (nonatomic, retain) NSDictionary *question;
@property (nonatomic, copy) NSString *evalPath;

- (NSNumber *) isAnswerValid;
- (void) displayValidAnswer;

@end
