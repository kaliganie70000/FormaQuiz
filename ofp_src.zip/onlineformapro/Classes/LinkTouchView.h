//
//  LinkTouchView.h
//  Liaisons
//
//  Created by Stephan on 09.03.09.
//  Copyright 2009 Coriolis Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Spot.h"

//==========================================================================================


@interface LinkTouchView : UIView {
	CGPoint loc1, loc2;
	NSMutableArray *left_spots;
	NSMutableArray *right_spots;
	
	CGColorRef drawingColor;
	UIImage *dotimage;
	BOOL isMoving;
	Spot *spot_src, *spot_dst;
}

- (id) initWithQuestionCount:(int)count;

@property (nonatomic) CGPoint loc1;
@property (nonatomic) CGPoint loc2;
@property (nonatomic) BOOL isMoving;
@property (nonatomic, retain) Spot *spot_src;
@property (nonatomic, retain) Spot *spot_dst;
@property (nonatomic, retain) UIImage *dotimage;
@property (nonatomic, assign) CGColorRef drawingColor;

- (Spot *) spotAtPoint:(CGPoint)touchePoint fuzzy:(BOOL)fuzzy;
- (BOOL) canLink:(Spot *)spot1 with:(Spot *)spot2;
- (void) unlinkSpot:(Spot *)spot;
- (void) linkSpot:(Spot *)spot1 withSpot:(Spot *)spot2;
- (NSString *) answerAsString;
- (void) displayValidAnswer:(NSString *)answer;

@end
