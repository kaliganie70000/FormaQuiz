//
//  Liaisons_QuestionViewController.h
//  onlineformapro
//
//  Created by Stephan on 07.03.09.
//  Copyright 2009 Coriolis Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LinkTouchView.h"


@interface Liaisons_QuestionViewController : UIViewController {
	
	IBOutlet UILabel *answer1Label_G;
	IBOutlet UILabel *answer2Label_G;
	IBOutlet UILabel *answer3Label_G;
	IBOutlet UILabel *answer4Label_G;
	IBOutlet UILabel *answer5Label_G;

	IBOutlet UILabel *answer1Label_D;
	IBOutlet UILabel *answer2Label_D;
	IBOutlet UILabel *answer3Label_D;
	IBOutlet UILabel *answer4Label_D;
	IBOutlet UILabel *answer5Label_D;

	IBOutlet UIButton *dragZone1_G;
	IBOutlet UIButton *dragZone2_G;
	IBOutlet UIButton *dragZone3_G;
	IBOutlet UIButton *dragZone4_G;
	IBOutlet UIButton *dragZone5_G;

	IBOutlet UIButton *dragZone1_D;
	IBOutlet UIButton *dragZone2_D;
	IBOutlet UIButton *dragZone3_D;
	IBOutlet UIButton *dragZone4_D;
	IBOutlet UIButton *dragZone5_D;
	
	LinkTouchView *drawingView;
	NSDictionary *question;
	NSString *evalPath;

}

@property (nonatomic, retain)  UILabel *answer1Label_G;
@property (nonatomic, retain)  UILabel *answer2Label_G;
@property (nonatomic, retain)  UILabel *answer3Label_G;
@property (nonatomic, retain)  UILabel *answer4Label_G;
@property (nonatomic, retain)  UILabel *answer5Label_G;

@property (nonatomic, retain)  UILabel *answer1Label_D;
@property (nonatomic, retain)  UILabel *answer2Label_D;
@property (nonatomic, retain)  UILabel *answer3Label_D;
@property (nonatomic, retain)  UILabel *answer4Label_D;
@property (nonatomic, retain)  UILabel *answer5Label_D;

@property (nonatomic, retain)  UIButton *dragZone1_G;
@property (nonatomic, retain)  UIButton *dragZone2_G;
@property (nonatomic, retain)  UIButton *dragZone3_G;
@property (nonatomic, retain)  UIButton *dragZone4_G;
@property (nonatomic, retain)  UIButton *dragZone5_G;

@property (nonatomic, retain)  UIButton *dragZone1_D;
@property (nonatomic, retain)  UIButton *dragZone2_D;
@property (nonatomic, retain)  UIButton *dragZone3_D;
@property (nonatomic, retain)  UIButton *dragZone4_D;
@property (nonatomic, retain)  UIButton *dragZone5_D;

@property (nonatomic, retain) NSDictionary *question;
@property (nonatomic, copy) NSString *evalPath;

- (NSNumber *) isAnswerValid;
- (void) displayValidAnswer;

@end
