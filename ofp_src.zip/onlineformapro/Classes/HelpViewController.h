//
//  HelpViewController.h
//  onlineformapro
//
//  Created by Stephan on 04.03.09.
//  Copyright 2009 Coriolis Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface HelpViewController : UIViewController {

}

- (IBAction) doneWithHelp:(id)sender;

@end
