//
//  InfoQuestionViewController.m
//  onlineformapro
//
//  Created by Stephan on 06.03.09.
//  Copyright 2009 Coriolis Technologies. All rights reserved.
//

#import "InfoQuestionViewController.h"


@implementation InfoQuestionViewController

@synthesize infoWebView;
@synthesize infoText;
@synthesize infoMedia;
@synthesize evalPath;

//==========================================================================================
- (IBAction) closeDialog:(id)sender
{
	[self.parentViewController dismissModalViewControllerAnimated:YES];
}

//==========================================================================================
- (void)viewDidLoad
{
	[super viewDidLoad];
}

//==========================================================================================
- (void) viewWillAppear:(BOOL) animated
{
	MARK;
	CMLog(@"text: %@", infoText);
	self.navigationController.navigationBarHidden = YES;
	[super viewWillAppear:animated];
}

//==========================================================================================
- (void) viewDidAppear:(BOOL) animated
{
	NSMutableString *htmlText = [NSMutableString stringWithString:@"<body style=\"background-color:#474B56\">"];
	
	if ([infoMedia length]) {
		[htmlText appendFormat:@"<img src=\"../%@\" width=\"100px\" align=left style=\"padding:0 5px 5px 0\">", infoMedia];
	}

	[htmlText appendFormat:@"<div style=\"font-family:Helvetica;font-size:14px;background-color:#474B56;color:white;text-align:justify\">%@</div></body>", infoText];
	[infoWebView stopLoading];
	NSString *imagePath = self.evalPath;
	imagePath = [imagePath stringByReplacingOccurrencesOfString:@"/" withString:@"//"];
	imagePath = [imagePath stringByReplacingOccurrencesOfString:@" " withString:@"%20"];
	infoWebView.detectsPhoneNumbers = NO;
	[infoWebView stopLoading];
	[infoWebView loadHTMLString:htmlText baseURL:[NSURL URLWithString:[NSString stringWithFormat:@"file:/%@//",imagePath]]];
	[super viewDidAppear:animated];
}

//==========================================================================================
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
	// Return YES for supported orientations
	return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

//==========================================================================================
- (void)didReceiveMemoryWarning
{
	[super didReceiveMemoryWarning]; // Releases the view if it doesn't have a superview
}

//==========================================================================================
- (void)dealloc
{
	[infoText release];
	[infoMedia release];
	[evalPath release];
	infoWebView.delegate = nil;
	[infoWebView stopLoading];
	[infoWebView release];
	[super dealloc];
}

@end
