//
//  EvalListViewCell.h
//  onlineformapro
//
//  Created by Stephan on 05.03.09.
//  Copyright 2009 Coriolis Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface EvalListViewCell : UITableViewCell {

	IBOutlet UILabel *evalTitle;
	IBOutlet UIImageView *evalLevel;
	IBOutlet UIImageView *evalStatus;
	IBOutlet UILabel *scoreLabel;
}

@property (nonatomic, retain) UILabel *evalTitle;
@property (nonatomic, retain) UIImageView *evalLevel;
@property (nonatomic, retain) UIImageView *evalStatus;
@property (nonatomic, retain) UILabel *scoreLabel;

@end
