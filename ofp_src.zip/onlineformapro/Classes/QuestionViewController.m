//
//  QuestionViewController.m
//  onlineformapro
//
//  Created by Stephan on 06.03.09.
//  Copyright 2009 Coriolis Technologies. All rights reserved.
//

#import "Reachability.h"
#import "onlineformaproAppDelegate.h"
#import "QuestionViewController.h"
#import "InfoQuestionViewController.h"
#import "AideQuestionViewController.h"
#import "QCM_QuestionViewController.h"
#import "Text_QuestionViewController.h"
#import "Images_QuestionViewController.h"
#import "Liaisons_QuestionViewController.h"
#import "ScoreViewController.h"
#import "Answer_ViewController.h"

@implementation QuestionViewController

@synthesize passButton;
@synthesize validateButton;
@synthesize nextButton;
@synthesize listenButton;
@synthesize commentButton;
@synthesize infoButton;
@synthesize goBackButton;
@synthesize timeLabel;
@synthesize counterLabel;
@synthesize questionLabel;
@synthesize chronoImage;

@synthesize resultatXML;
@synthesize evalPath;
@synthesize evalGUID;
@synthesize questionListArray;
@synthesize currentQuestionIndex;
@synthesize startTime;
@synthesize timeLimit;
@synthesize scoreMax;

@synthesize currentQuestionViewController;

@synthesize audioPlayer;

//==========================================================================================
- (void)viewDidLoad
{
	[self initQuestionnaire];
	[super viewDidLoad];
}

//==========================================================================================
- (void) viewWillAppear:(BOOL) animated
{
	MARK;
	if (timeLimit == 0) {
		chronoImage.hidden = TRUE;
		timeLabel.hidden = TRUE;
	} else {
		chronoTimer = [NSTimer scheduledTimerWithTimeInterval:1.0 target:self selector:@selector(updateChrono:) userInfo:nil repeats:YES];
		timeLabel.text = @"00:00";
	}
	self.navigationController.navigationBarHidden = YES;
}

//==========================================================================================
- (void) viewDidAppear:(BOOL) animated
{
	MARK;
}

//==========================================================================================
- (void) viewWillDisappear:(BOOL) animated
{
	[chronoTimer invalidate];
	self.navigationController.navigationBarHidden = NO;
	[super viewWillDisappear:animated];
}

//==========================================================================================
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
	// Return YES for supported orientations
	return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

//==========================================================================================
- (void)didReceiveMemoryWarning
{
	MARK;
	[super didReceiveMemoryWarning]; // Releases the view if it doesn't have a superview
	// Release anything that's not essential, such as cached data
}

//==========================================================================================
- (void) updateChrono:(NSTimer *)timer
{
	int elapsedTime = -(int)[startTime timeIntervalSinceNow];
	if (elapsedTime > 5999) {
		timeLabel.text = @"99:99";		
	} else {
		NSString *timeAsString = [NSString stringWithFormat:@"%02d:%02d", (int)(elapsedTime/60), (int)(elapsedTime % 60)];
		timeLabel.text = timeAsString;
	}
}

//==========================================================================================
- (void) initQuestionnaire
{
	self.currentQuestionIndex = 0;
	score = 0;
	self.startTime = [NSDate date];
	self.resultatXML = [NSMutableString string];
	self.currentQuestionViewController = nil;
	self.audioPlayer = NULL;
}

//==========================================================================================
- (void) displayNextQuestion
{
	if (audioPlayer != NULL) {
		audioPlayer.delegate = nil;
		[audioPlayer stop];
		[audioPlayer release];
		audioPlayer = NULL;
	}

	if (currentQuestionIndex < [questionListArray count]) {
		validateButton.hidden = NO;
		passButton.hidden = NO;
		nextButton.hidden = YES;
		infoButton.hidden = YES;
		currentQuestionIndex++;
		NSDictionary *question = [questionListArray objectAtIndex:currentQuestionIndex-1];
		CMLog(@"question: %@", question);
		if ([[question objectForKey:@"consigneAudio"] length]) {
			listenButton.hidden = NO;
			NSString *media = [question objectForKey:@"consigneAudio"];
			NSString *mediaPath = [NSString stringWithFormat:@"%@/%@", evalPath, media];
			NSData *data = [NSData dataWithContentsOfFile:mediaPath];
			if (data) {
				audioPlayer = [[AVAudioPlayer alloc] initWithData:data error:nil];
				audioPlayer.volume = [[NSUserDefaults standardUserDefaults] floatForKey:kPREF_SOUNDVOLUME];
				[audioPlayer prepareToPlay];
				audioPlayer.delegate = self;
				if ([[NSUserDefaults standardUserDefaults] boolForKey:kPREF_PLAYSOUND])
					[self listenSound:nil];
			}
		} else {
			listenButton.hidden = YES;
		}
		
		if ([[question objectForKey:@"commentaireAide"] length]) {
			commentButton.hidden = NO;
		} else {
			commentButton.hidden = YES;
		}
		
		nextButton.hidden = YES;
		int question_type = [[question objectForKey:@"type"] intValue];
		UIViewController *viewController;
		switch (question_type) {
			case 0:
			case 1:
				viewController = (UIViewController *)[[QCM_QuestionViewController alloc] initWithNibName:@"QCM_QuestionViewController" bundle:nil];
				if (question_type == 0) {
					((QCM_QuestionViewController *)viewController).qcm = NO;
				} else {
					((QCM_QuestionViewController *)viewController).qcm = YES;
				}
				((QCM_QuestionViewController *)viewController).question = question;
				((QCM_QuestionViewController *)viewController).evalPath = evalPath;
				break;
			case 4: // choix image
				viewController = (UIViewController *)[[Images_QuestionViewController alloc] initWithNibName:@"Images_QuestionViewController" bundle:nil];
				((Images_QuestionViewController *)viewController).question = question;
				((Images_QuestionViewController *)viewController).evalPath = evalPath;
				break;
			case 5: // liaison
				viewController = (UIViewController *)[[Liaisons_QuestionViewController alloc] initWithNibName:@"Liaisons_QuestionViewController" bundle:nil];
				((Liaisons_QuestionViewController *)viewController).question = question;
				((Liaisons_QuestionViewController *)viewController).evalPath = evalPath;
				break;
			case 15: // saisie texte
				viewController = (UIViewController *)[[Text_QuestionViewController alloc] initWithNibName:@"Text_QuestionViewController" bundle:nil];
				((Text_QuestionViewController *)viewController).question = question;
				((Text_QuestionViewController *)viewController).evalPath = evalPath;
				break;
			default:
				break;
		}
		CGRect frame = viewController.view.frame;
		frame.origin.y = 112.0f;
		viewController.view.frame = frame;
		if (currentQuestionViewController != NULL) {
			[currentQuestionViewController.view removeFromSuperview];
			[currentQuestionViewController release];
		}
		[self.view insertSubview:viewController.view atIndex:[[self.view subviews] count]+1];
		[viewController viewWillAppear:YES];
		currentQuestionViewController = viewController;

		CGSize maximumLabelSize = CGSizeMake(297,9999);
		NSMutableString *enonce = [NSMutableString stringWithString:[question objectForKey:@"enonce"]];
		[enonce replaceOccurrencesOfString:@" ?" withString:@"?" options:NSLiteralSearch range:NSMakeRange(0, [enonce length])];
		[enonce replaceOccurrencesOfString:@"\n" withString:@" " options:NSLiteralSearch range:NSMakeRange(0, [enonce length])];
		CGFloat fontSize = 17.0f;
		BOOL done = FALSE;
		self.questionLabel.text = enonce;
		while (!done) {
			CGSize expectedLabelSize = [enonce sizeWithFont:[UIFont boldSystemFontOfSize:fontSize]
																				constrainedToSize:maximumLabelSize 
																						lineBreakMode:UILineBreakModeWordWrap];
			
			if (expectedLabelSize.height > questionLabel.frame.size.height) {
				fontSize = fontSize - 1.0f;
				if (fontSize <= 10.0f)
					done = TRUE;
			} else {
				done = TRUE;
			}
		}
		questionLabel.font = [UIFont systemFontOfSize:fontSize];
		self.counterLabel.text = [NSString stringWithFormat:@"%d/%d", currentQuestionIndex, [questionListArray count]];
	} else {
		[self displayScore];
	}
}

//==========================================================================================
- (IBAction) passQuestion:(id)sender
{
	NSDictionary *question = [questionListArray objectAtIndex:currentQuestionIndex-1];
	CMLog(@"question: %@", question);
	[resultatXML appendFormat:@"<question id_question=\"%@\" score=\"%d\" coef_question=\"%d\">\n<reponse_usager></reponse_usager>\n<reponse_correcte>%@</reponse_correcte>\n</question>\n",
	 [question objectForKey:@"idQuestion"],
	 0,
	 [[question objectForKey:@"coef"] intValue],
	 [question objectForKey:@"solutions"]];
	[self displayNextQuestion];
}

//==========================================================================================
- (IBAction) validateQuestion:(id)sender
{
	if (audioPlayer) {
		if ([audioPlayer isPlaying]) {
			[audioPlayer pause];
			[audioPlayer setCurrentTime:0.0f];
			[listenButton setBackgroundImage:[UIImage imageNamed:@"play_sound_btn.png"] forState:UIControlStateNormal];
			[listenButton setBackgroundImage:[UIImage imageNamed:@"play_sound_btn.png"] forState:UIControlStateHighlighted];
		}
	}

	if ([sender tag] == 999) {
		currentAnswerValid = [[currentQuestionViewController performSelector:@selector(isAnswerValid)] boolValue];
//		CMLog(@"Valid: %@", (currentAnswerValid ? @"YES":@"NO"));
		if ([[NSUserDefaults standardUserDefaults] boolForKey:kPREF_SHOWANSWERS]) {
			[currentQuestionViewController performSelector:@selector(displayValidAnswer)];
		} else {
			Answer_ViewController *viewController = [[Answer_ViewController alloc] initWithNibName:@"Answer_ViewController" bundle:nil];
			viewController.validAnswer = currentAnswerValid;
			CGRect frame = viewController.view.frame;
			frame.origin.y = 44.0f;
			viewController.view.frame = frame;
			if (currentQuestionViewController != NULL) {
				[currentQuestionViewController.view removeFromSuperview];
				[currentQuestionViewController release];
			}
			[self.view insertSubview:viewController.view atIndex:[[self.view subviews] count]+1];
			if (currentAnswerValid) {
			} else {
				viewController.imageView.image = [UIImage imageNamed:@"faux_sans_reponse.png"];
			}
			[viewController viewWillAppear:YES];
			currentQuestionViewController = viewController;			
		}
		NSDictionary *question = [questionListArray objectAtIndex:currentQuestionIndex-1];
//		CMLog(@"question: %@", question);
		[resultatXML appendFormat:@"<question id_question=\"%@\" score=\"%d\" coef_question=\"%d\">\n<reponse_usager></reponse_usager>\n<reponse_correcte>%@</reponse_correcte>\n</question>\n",
		 [question objectForKey:@"idQuestion"],
		 (currentAnswerValid ? 1:0),
		 [[question objectForKey:@"coef"] intValue],
		 [question objectForKey:@"solutions"]];

		if (currentAnswerValid) {
			score++;
			if ([[question objectForKey:@"commentaireJuste"] length]) {
				infoButton.hidden = NO;
			}
		} else {
			if ([[question objectForKey:@"commentaireFaux"] length]) {
				infoButton.hidden = NO;
			}
		}
		validateButton.hidden = YES;
		passButton.hidden = YES;
		commentButton.hidden = YES;
		nextButton.hidden = NO;
	}

}

//==========================================================================================
- (IBAction) listenSound:(id)sender
{
	if (audioPlayer) {
		if ([audioPlayer isPlaying]) {
			[audioPlayer pause];
			[audioPlayer setCurrentTime:0.0f];
			[listenButton setBackgroundImage:[UIImage imageNamed:@"play_sound_btn.png"] forState:UIControlStateNormal];
			[listenButton setBackgroundImage:[UIImage imageNamed:@"play_sound_btn.png"] forState:UIControlStateHighlighted];
		} else {
			[audioPlayer play];
			[listenButton setBackgroundImage:[UIImage imageNamed:@"stop_sound_btn.png"] forState:UIControlStateNormal];
			[listenButton setBackgroundImage:[UIImage imageNamed:@"stop_sound_btn.png"] forState:UIControlStateHighlighted];
		}
	}
}

//==========================================================================================
- (IBAction) displayInfo:(id)sender
{
	InfoQuestionViewController *viewController = [[InfoQuestionViewController alloc] initWithNibName:@"InfoQuestionViewController" bundle:nil];
	NSString *infoText = @"";
	NSString *infoMedia = @"";
	if (currentAnswerValid) {
		infoText = [[self.questionListArray objectAtIndex:currentQuestionIndex-1] objectForKey:@"commentaireJuste"];
		infoMedia = [[self.questionListArray objectAtIndex:currentQuestionIndex-1] objectForKey:@"mediaJuste"]; 
	} else {
		infoText = [[self.questionListArray objectAtIndex:currentQuestionIndex-1] objectForKey:@"commentaireFaux"];
		infoMedia = [[self.questionListArray objectAtIndex:currentQuestionIndex-1] objectForKey:@"mediaFaux"]; 
	}

	viewController.infoText = infoText;
	viewController.infoMedia = infoMedia;
	viewController.evalPath = evalPath;
	[self.navigationController presentModalViewController:viewController animated:YES];
//	[viewController.infoTextView performSelectorOnMainThread:@selector(setText:) withObject:info waitUntilDone:YES];
	[viewController release];
}

//==========================================================================================
- (IBAction) displayComment:(id)sender
{
	AideQuestionViewController *viewController = [[AideQuestionViewController alloc] initWithNibName:@"AideQuestionViewController" bundle:nil];
	viewController.aideTextView.text = [[self.questionListArray objectAtIndex:currentQuestionIndex-1] objectForKey:@"commentaireAide"];
	[self presentModalViewController:viewController animated:YES];	
	[viewController release];
}

//==========================================================================================
- (IBAction) goNext:(id)sender
{
	[self displayNextQuestion];
}

//==========================================================================================
- (IBAction) goBack:(id)sender
{
	if (audioPlayer != NULL) {
		audioPlayer.delegate = nil;
		[audioPlayer stop];
		[audioPlayer release];
		audioPlayer = NULL;
	}

	[UIView beginAnimations:nil context:NULL];
	[UIView setAnimationDuration: 0.5f];
	self.navigationController.navigationBarHidden = NO;
	[UIView setAnimationTransition:UIViewAnimationTransitionFlipFromRight forView:self.navigationController.view cache:NO];
	[self.navigationController popViewControllerAnimated:NO];
	[UIView commitAnimations];
}

//==========================================================================================
- (void) displayScore
{
	FMDatabase *db = [[OFPDatabase sharedInstance] ofp_DB];
	[db executeUpdate :@"DELETE FROM evaluation WHERE guid = ?", self.evalGUID];
	[db executeUpdate :@"INSERT INTO evaluation (eval_done, score, score_max, guid) VALUES (?, ?, ?, ?)", @"1", [NSNumber numberWithInt:score], [NSNumber numberWithInt:scoreMax], self.evalGUID];

	int elapsedTime = -(int)[startTime timeIntervalSinceNow];

	NSString *fullResultat = [NSString stringWithFormat:@"<?xml version=\"1.0\" encoding=\"UTF-8\" ?>\n<resultats guid=\"%@\" score=\"%d\" temps=\"%d\">\n%@</resultats>", 
														self.evalGUID, score, 
														elapsedTime, 
														resultatXML];

	[db executeUpdate :@"DELETE FROM resultats WHERE guid = ?", self.evalGUID];
	[db executeUpdate :@"INSERT INTO resultats (guid, data) VALUES (?, ?)", self.evalGUID, fullResultat];

	ScoreViewController *viewController = [[ScoreViewController alloc] initWithNibName:@"ScoreViewController" bundle:nil];
	viewController.score = [NSString stringWithFormat:@"%d/%d", score, [questionListArray count]];
	[UIView beginAnimations:nil context:NULL];
	[UIView setAnimationDuration: 0.5f];
	[UIView setAnimationTransition:UIViewAnimationTransitionFlipFromRight forView:self.navigationController.view cache:NO];
	[self.navigationController pushViewController:viewController animated:NO];
	[UIView commitAnimations];
	[viewController release];
}

//==========================================================================================
- (void)dealloc
{
	
	[passButton release];
	[validateButton release];
	[nextButton release];
	[listenButton release];
	[commentButton release];
	[infoButton release];
	[goBackButton release];
	[timeLabel release];
	[counterLabel release];
	[questionLabel release];
	[chronoImage release];
	
	[resultatXML release];
	[evalPath release];
	[evalGUID release];
	[questionListArray release];
	[startTime release];
	
	[currentQuestionViewController release];

	audioPlayer.delegate = nil;
	[audioPlayer release];

	[super dealloc];
}

//==========================================================================================
- (void)audioPlayerDidFinishPlaying:(AVAudioPlayer *)player successfully:(BOOL)flag
{
	MARK;
	[listenButton setBackgroundImage:[UIImage imageNamed:@"play_sound_btn.png"] forState:UIControlStateNormal];
	[listenButton setBackgroundImage:[UIImage imageNamed:@"play_sound_btn.png"] forState:UIControlStateHighlighted];
}

@end
