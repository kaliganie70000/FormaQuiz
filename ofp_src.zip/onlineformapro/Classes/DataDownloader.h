//
//  DataDownloader.h
//  onlineformapro
//
//  Created by Stephan on 02.02.09.
//  Copyright 2009 Coriolis Technologies. All rights reserved.
//

#import <Foundation/Foundation.h>


#define DataDownloaderRunMode @"ofp.run_mode"

@interface DataDownloader : NSObject {
	NSString *dataURL;
	NSMutableData *responseData;
	NSError *connectionError;
	double	timeoutInterval;
	BOOL finished;
}

@property (nonatomic, retain) NSMutableData *responseData;
@property (nonatomic, retain) NSString *dataURL;
@property (nonatomic, retain) NSError *connectionError;
@property (nonatomic, assign) double timeoutInterval;

- (id)initWithDataURL:(NSString *)theDataURL;
- (NSData *)downloadWithErrorHandle:(NSError **)error;

@end
