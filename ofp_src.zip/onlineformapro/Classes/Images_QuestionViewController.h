//
//  Images_QuestionViewController.h
//  onlineformapro
//
//  Created by Stephan on 07.03.09.
//  Copyright 2009 Coriolis Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface Images_QuestionViewController : UIViewController {

	IBOutlet UIImageView *image1View;
	IBOutlet UIImageView *image2View;
	IBOutlet UIImageView *image3View;
	IBOutlet UIImageView *image4View;

	IBOutlet UIButton *button1;
	IBOutlet UIButton *button2;
	IBOutlet UIButton *button3;
	IBOutlet UIButton *button4;

	NSDictionary *question;
	NSString *evalPath;
}

@property (nonatomic, retain) UIImageView *image1View;
@property (nonatomic, retain) UIImageView *image2View;
@property (nonatomic, retain) UIImageView *image3View;
@property (nonatomic, retain) UIImageView *image4View;
@property (nonatomic, retain) UIButton *button1;
@property (nonatomic, retain) UIButton *button2;
@property (nonatomic, retain) UIButton *button3;
@property (nonatomic, retain) UIButton *button4;
@property (nonatomic, retain) NSDictionary *question;
@property (nonatomic, copy) NSString *evalPath;

- (IBAction) buttonClicked:(id)sender;
- (NSNumber *) isAnswerValid;
- (void) displayValidAnswer;


@end
