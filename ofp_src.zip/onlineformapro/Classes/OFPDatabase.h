//
//  OFPDatabase.h
//  onlineformapro
//
//  Created by Stephan on 09.12.08.
//  Copyright 2008 Coriolis Technologies. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FMDatabase.h"

@interface OFPDatabase : NSObject {
	FMDatabase *ofp_DB;
	NSInteger		dbVersion;
}

@property (nonatomic, assign) NSInteger dbVersion;
@property (nonatomic, readonly) FMDatabase *ofp_DB;

+ (OFPDatabase *) sharedInstance;
- (void) vacuum;

@end
