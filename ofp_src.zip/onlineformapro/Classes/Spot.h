//
//  Spot.h
//  Liaisons
//
//  Created by Stephan on 09.03.09.
//  Copyright 2009 Coriolis Technologies. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface Spot : NSObject {
	CGRect frame;
	CGPoint center;
	Spot *brother;
}

@property (nonatomic, assign) CGRect frame;
@property (nonatomic, assign) CGPoint center;
@property (nonatomic, assign) Spot *brother;

@end
