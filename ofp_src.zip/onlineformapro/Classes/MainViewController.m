//
//  MainViewController.m
//  onlineformapro
//
//  Created by Stephan on 02.03.09.
//  Copyright 2009 Coriolis Technologies. All rights reserved.
//

#import "MainViewController.h"
#import "onlineformaproAppDelegate.h"
#import "ThemeViewController.h"
#import "LoginViewController.h"
#import "HelpViewController.h"
#import "SettingsViewController.h"
#import "Reachability.h"
#import "OFPDatabase.h"
#import "Reachability.h"

@implementation MainViewController

@synthesize beginButton;
@synthesize optionButton;
@synthesize helpButton;
@synthesize versionLabel;
//@synthesize navigationController;

//==========================================================================================
- (void)viewDidLoad
{
	[super viewDidLoad];
}

//==========================================================================================
- (void) viewWillAppear: (BOOL)animated
{
	self.navigationController.navigationBarHidden = YES;
	NSString *appVersion = [[NSBundle mainBundle] objectForInfoDictionaryKey:@"CFBundleShortVersionString"];
//	NSString *subappVersion = [[NSBundle mainBundle] objectForInfoDictionaryKey:@"CFBundleVersion"];
//	NSString *versionString = [NSString stringWithFormat:@"%@.%@", appVersion, subappVersion];
	versionLabel.text = appVersion;

	[super viewWillAppear:animated];
}

//==========================================================================================
- (void) viewDidAppear:(BOOL) animated
{
	Reachability *reachManager = [Reachability sharedReachability];
	[reachManager setHostName:kMAIN_URL];
	NetworkStatus remoteHostStatus         = [[Reachability sharedReachability] remoteHostStatus];
	NetworkStatus internetConnectionStatus = [[Reachability sharedReachability] internetConnectionStatus];
	
	if ((internetConnectionStatus != NotReachable) || (remoteHostStatus != NotReachable)) {
		FMDatabase *ofp_DB = [[OFPDatabase sharedInstance] ofp_DB];
		FMResultSet *rs = [ofp_DB executeQuery:@"SELECT COUNT(*) from resultats"];
		if (rs && [rs next]) {
			NSInteger count = [rs intForColumnIndex:0];
			[rs close];
	//		count = 1;
			if (count > 0) {
				hudWindow = [[SFHFHUDView alloc] initWithFrame:self.view.frame];
				[hudWindow makeKeyAndVisible];
				[hudWindow setStatusText:@"Envoi des résultats"];
				hudWindow.showsStatusLabel = TRUE;
				[hudWindow startActivityIndicator];
				[self performSelector:@selector(sendRemainingResultsToServer) withObject:nil afterDelay:0.2];
			}
		}
	}
	[super viewDidAppear:animated];
}

//==========================================================================================
- (void) sendRemainingResultsToServer
{
	MARK;
//	[UIAppDelegate performSelectorOnMainThread:@selector(sendRemainingResultsToServer) withObject:nil  waitUntilDone:YES];
	[UIAppDelegate sendRemainingResultsToServer];
//	NSDate *future = [NSDate dateWithTimeIntervalSinceNow:1.0f ];
//	[NSThread sleepUntilDate:future];
	[hudWindow stopActivityIndicator];
	[hudWindow release];
	CMLog(@"done");
}

//==========================================================================================
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
	// Return YES for supported orientations
	return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

//==========================================================================================
- (void)didReceiveMemoryWarning
{
	[super didReceiveMemoryWarning]; // Releases the view if it doesn't have a superview
	// Release anything that's not essential, such as cached data
}

//==========================================================================================
- (void)dealloc
{
	[versionLabel release];
	[beginButton release];
	[optionButton release];
	[helpButton release];
	[super dealloc];
}

//==========================================================================================
- (IBAction) start:(id)sender
{
	NSArray *evalList = NULL;
	NetworkStatus remoteHostStatus         = [[Reachability sharedReachability] remoteHostStatus];
	NetworkStatus internetConnectionStatus = [[Reachability sharedReachability] internetConnectionStatus];
	
	CMLog(@"internetConnectionStatus: %d, remoteHostStatus: %d", internetConnectionStatus, remoteHostStatus);
	
	if ((internetConnectionStatus == NotReachable) && (remoteHostStatus == NotReachable)) {
		NSString *evalPath = [NSString stringWithFormat:@"%@/eval_list.xml", [UIAppDelegate documentsPath]];
		if ([[NSFileManager defaultManager] fileExistsAtPath:evalPath]) {
			evalList = [NSArray arrayWithContentsOfFile:evalPath];
			if (evalList && ([evalList count]))
				evalList = [UIAppDelegate postProcessEvalList:evalList];
		}
	} else {
		if ([UIAppDelegate loginWithStoredUserAndPassword]) {
			evalList = [UIAppDelegate evalListFromServer];
			if (evalList == NULL) 
				return;
		} else {
			LoginViewController *viewController = [[LoginViewController alloc] initWithNibName:@"LoginViewController" bundle:nil];
			[self presentModalViewController:viewController animated:YES];
			[viewController release];
			return;
		}
	}

	if (evalList != NULL) {
		[UIView beginAnimations:nil context:NULL];
		[UIView setAnimationDuration: 0.5f];
		ThemeViewController *viewController = [[ThemeViewController alloc] initWithNibName:@"ThemeViewController" bundle:nil];
		viewController.themeList = evalList;
//		navigationController = [[UINavigationController alloc] initWithRootViewController:viewController];
		[self.navigationController pushViewController:viewController animated:NO];
//		[[UIAppDelegate window] addSubview:viewController.view];
		[UIView setAnimationTransition:UIViewAnimationTransitionFlipFromLeft forView:self.navigationController.view cache:NO];
		[UIView commitAnimations];
		[viewController release];
	} else {
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Attention" message:@"Vous n'avez pas téléchargé d'évaluation et vous devez avoir une connexion internet pour pouvoir effectuer un téléchargement." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
		[alert show];
		[alert release];	
	}
}

//==========================================================================================
- (IBAction) showOptions:(id)sender
{
	SettingsViewController *viewController = [[SettingsViewController alloc] initWithNibName:@"SettingsViewController" bundle:nil];
	[self presentModalViewController:viewController animated:YES];
	[viewController release];
}

//==========================================================================================
- (IBAction) showHelp:(id)sender
{
	HelpViewController *viewController = [[HelpViewController alloc] initWithNibName:@"HelpViewController" bundle:nil];
	[self presentModalViewController:viewController animated:YES];
	[viewController release];
}

@end
