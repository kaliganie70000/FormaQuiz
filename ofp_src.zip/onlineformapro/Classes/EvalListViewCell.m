//
//  EvalListViewCell.m
//  onlineformapro
//
//  Created by Stephan on 05.03.09.
//  Copyright 2009 Coriolis Technologies. All rights reserved.
//

#import "EvalListViewCell.h"


@implementation EvalListViewCell

@synthesize evalTitle;
@synthesize evalLevel;
@synthesize evalStatus;
@synthesize scoreLabel;

- (id)initWithFrame:(CGRect)frame reuseIdentifier:(NSString *)reuseIdentifier
{
	if (self = [super initWithFrame:frame reuseIdentifier:reuseIdentifier]) {
			// Initialization code
	}
	return self;
}

//==========================================================================================
- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
	[super setSelected:selected animated:animated];
	// Configure the view for the selected state
}

//==========================================================================================
- (void)dealloc
{
	[scoreLabel release];
	[evalLevel release];
	[evalTitle release];
	[evalStatus release];
	[super dealloc];
}

@end
