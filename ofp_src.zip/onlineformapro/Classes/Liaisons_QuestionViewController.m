//
//  Liaisons_QuestionViewController.m
//  onlineformapro
//
//  Created by Stephan on 07.03.09.
//  Copyright 2009 Coriolis Technologies. All rights reserved.
//

#import "Liaisons_QuestionViewController.h"

//==========================================================================================

@implementation Liaisons_QuestionViewController

@synthesize answer1Label_G;
@synthesize answer2Label_G;
@synthesize answer3Label_G;
@synthesize answer4Label_G;
@synthesize answer5Label_G;
@synthesize answer1Label_D;
@synthesize answer2Label_D;
@synthesize answer3Label_D;
@synthesize answer4Label_D;
@synthesize answer5Label_D;
@synthesize dragZone1_G;
@synthesize dragZone2_G;
@synthesize dragZone3_G;
@synthesize dragZone4_G;
@synthesize dragZone5_G;
@synthesize dragZone1_D;
@synthesize dragZone2_D;
@synthesize dragZone3_D;
@synthesize dragZone4_D;
@synthesize dragZone5_D;

@synthesize question;
@synthesize evalPath;

//==========================================================================================
- (void) viewWillAppear:(BOOL)animated
{
	MARK;
	int numQuestions = 5;
	CMLog(@"propositions: %@", [question objectForKey:@"propositions"]);
	NSArray *questionList = [[question objectForKey:@"propositions"] componentsSeparatedByString:@"*^*"];
	CMLog(@"questionList: %@", questionList)
	if ([[questionList objectAtIndex:4] length] == 0) {
		numQuestions = 4;
		answer5Label_G.hidden = YES;
		answer5Label_D.hidden = YES;
		dragZone5_D.hidden = YES;
		dragZone5_G.hidden = YES;
	}
	if ([[questionList objectAtIndex:3] length] == 0) {
		numQuestions = 3;
		answer4Label_G.hidden = YES;
		answer4Label_D.hidden = YES;
		dragZone4_D.hidden = YES;
		dragZone4_G.hidden = YES;
	}
	if ([[questionList objectAtIndex:2] length] == 0) {
		numQuestions = 2;
		answer3Label_G.hidden = YES;
		answer3Label_D.hidden = YES;
		dragZone3_D.hidden = YES;
		dragZone3_G.hidden = YES;
	}
	
	int index;
	for (index = 1 ; index <= 5 ; index++) {
		[self setValue:[questionList objectAtIndex:index-1] forKeyPath:[NSString stringWithFormat:@"answer%dLabel_G.text", index]];
		[self setValue:[questionList objectAtIndex:index+7-1] forKeyPath:[NSString stringWithFormat:@"answer%dLabel_D.text", index]];
	}
	drawingView = [[LinkTouchView alloc] initWithQuestionCount:numQuestions];
	CGRect frame = self.view.frame;
	frame.origin = CGPointZero;
	drawingView.frame = frame;
	[self.view addSubview:drawingView];
	//	[self displayValidAnswer];
}

//==========================================================================================
- (NSNumber *) isAnswerValid
{
	BOOL valid = FALSE;
	NSString *answer = [drawingView answerAsString];
	if ([answer isEqualToString:[question objectForKey:@"solutions"]])
		valid = TRUE;
	return [NSNumber numberWithBool:valid];
}

//==========================================================================================
- (void) displayValidAnswer
{
	[drawingView displayValidAnswer:[question objectForKey:@"solutions"]];
}

//==========================================================================================
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
	// Return YES for supported orientations
	return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

//==========================================================================================
- (void)didReceiveMemoryWarning
{
	[super didReceiveMemoryWarning]; // Releases the view if it doesn't have a superview
	// Release anything that's not essential, such as cached data
}

//==========================================================================================

- (void)dealloc
{
	[answer1Label_G release];
	[answer2Label_G release];
	[answer3Label_G release];
	[answer4Label_G release];
	[answer5Label_G release];
	[answer1Label_D release];
	[answer2Label_D release];
	[answer3Label_D release];
	[answer4Label_D release];
	[answer5Label_D release];
	[dragZone1_G release];
	[dragZone2_G release];
	[dragZone3_G release];
	[dragZone4_G release];
	[dragZone5_G release];
	[dragZone1_D release];
	[dragZone2_D release];
	[dragZone3_D release];
	[dragZone4_D release];
	[dragZone5_D release];
	
	[drawingView release];
	[evalPath release];
	[question release];
	[super dealloc];
}


@end
