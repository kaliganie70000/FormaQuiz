//
//  QuestionViewController.h
//  onlineformapro
//
//  Created by Stephan on 06.03.09.
//  Copyright 2009 Coriolis Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>


@interface QuestionViewController : UIViewController <AVAudioPlayerDelegate> {
	
	IBOutlet UIButton *passButton;
	IBOutlet UIButton *validateButton;
	IBOutlet UIButton *nextButton;
	IBOutlet UIButton *listenButton;
	IBOutlet UIButton *commentButton;
	IBOutlet UIButton *infoButton;
	IBOutlet UIButton *goBackButton;
	IBOutlet UILabel *timeLabel;
	IBOutlet UILabel *counterLabel;
	IBOutlet UILabel *questionLabel;
	IBOutlet UIImageView *chronoImage;
	
	NSMutableString *resultatXML;
	NSString *evalPath;
	NSString *evalGUID;
	NSArray *questionListArray;
	NSInteger currentQuestionIndex;
	NSDate *startTime;
	UIViewController *currentQuestionViewController;
	int score;
	NSInteger scoreMax;
	NSInteger timeLimit;
	BOOL currentAnswerValid;
	AVAudioPlayer *audioPlayer;
	NSTimer *chronoTimer;
}

@property (nonatomic, retain) UIButton *passButton;
@property (nonatomic, retain) UIButton *validateButton;
@property (nonatomic, retain) UIButton *nextButton;
@property (nonatomic, retain) UIButton *listenButton;
@property (nonatomic, retain) UIButton *commentButton;
@property (nonatomic, retain) UIButton *infoButton;
@property (nonatomic, retain) UIButton *goBackButton;
@property (nonatomic, retain) UILabel *timeLabel;
@property (nonatomic, retain) UILabel *counterLabel;
@property (nonatomic, retain) UILabel *questionLabel;
@property (nonatomic, retain) UIImageView *chronoImage;

@property (nonatomic, retain) NSMutableString *resultatXML;
@property (nonatomic, copy) NSString *evalPath;
@property (nonatomic, copy) NSString *evalGUID;
@property (nonatomic, retain) NSArray *questionListArray;
@property (nonatomic, assign) NSInteger currentQuestionIndex;
@property (nonatomic, retain) NSDate *startTime;
@property (nonatomic, assign) NSInteger timeLimit;
@property (nonatomic, assign) NSInteger scoreMax;

@property (nonatomic, retain) UIViewController *currentQuestionViewController;

@property (nonatomic, retain) AVAudioPlayer *audioPlayer;

- (void) displayNextQuestion;
- (IBAction) passQuestion:(id)sender;
- (IBAction) validateQuestion:(id)sender;
- (IBAction) listenSound:(id)sender;
- (IBAction) displayInfo:(id)sender;
- (IBAction) displayComment:(id)sender;
- (IBAction) goNext:(id)sender;
- (IBAction) goBack:(id)sender;

- (void) initQuestionnaire;
- (void) displayScore;

@end
