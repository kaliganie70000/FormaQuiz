//
//  SettingsViewController.h
//  onlineformapro
//
//  Created by Stephan on 04.03.09.
//  Copyright 2009 Coriolis Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface SettingsViewController : UIViewController {
	
	IBOutlet UISwitch *showAnswers;
	IBOutlet UISwitch *playSounds;
	IBOutlet UISlider *soundVolume;
}

@property (nonatomic, retain) UISwitch *showAnswers;
@property (nonatomic, retain) UISwitch *playSounds;
@property (nonatomic, retain) UISlider *soundVolume;

- (IBAction) doneWithSettings:(id)sender;
- (IBAction) displayCompteSettings:(id)sender;

@end
