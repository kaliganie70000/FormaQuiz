//
//  ScoreViewController.h
//  onlineformapro
//
//  Created by Stephan on 07.03.09.
//  Copyright 2009 Coriolis Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface ScoreViewController : UIViewController {
	
	IBOutlet UILabel *scoreLabel;
	IBOutlet UIView *progressView;
	NSString *score;

}

@property (nonatomic, retain) UILabel *scoreLabel;
@property (nonatomic, retain) UIView *progressView;
@property (nonatomic, copy) NSString *score;

- (IBAction) restart:(id)sender;
- (void) sendResults;

@end
