//
//  onlineformaproAppDelegate.h
//  onlineformapro
//
//  Created by Stephan on 23.02.09.
//  Copyright Coriolis Technologies 2009. All rights reserved.
//

#import <UIKit/UIKit.h>

#define UIAppDelegate ((onlineformaproAppDelegate *)[UIApplication sharedApplication].delegate)

@interface onlineformaproAppDelegate : NSObject <UIApplicationDelegate> {
	UIWindow *window;
	NSString *documentsPath;
	NSString *sendResultURL;
	UINavigationController *navigationController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, copy) NSString *documentsPath;
@property (nonatomic, copy) NSString *sendResultURL;
@property (nonatomic, retain) UINavigationController *navigationController;

- (NSData *) loadDataFromURL:(NSString *)dataURL;
- (void) redirectConsoleLogToDocumentFolder;
- (void)initializeUserDefaults;

- (NSString *)getSendResultURLFromServer:(NSString *)serverData;
- (NSInteger)statusFromServer:(NSString *)serverData;
- (NSString *)errorFromServer:(NSString *)serverData;
- (void) sendRemainingResultsToServer;
- (void) logout;
- (BOOL)loginWithStoredUserAndPassword;
- (BOOL)loginWithUser:(NSString *)username password:(NSString *)password client:(NSString *)clientID;
- (BOOL) sendResultatToServer:(NSString *)resultat;

- (NSArray *) evalListFromServer;
- (NSArray *) postProcessEvalList:(NSArray *)evalList;

- (BOOL) extractZipFile:(NSString *)zipfilename toFolder:(NSString *)folder;

@end

