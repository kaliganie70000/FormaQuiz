//
//  HelpViewController.m
//  onlineformapro
//
//  Created by Stephan on 04.03.09.
//  Copyright 2009 Coriolis Technologies. All rights reserved.
//

#import "HelpViewController.h"


@implementation HelpViewController

//==========================================================================================
- (void)viewDidLoad
{
	[super viewDidLoad];
}

//==========================================================================================
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
	// Return YES for supported orientations
	return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

//==========================================================================================
- (void)didReceiveMemoryWarning
{
	[super didReceiveMemoryWarning]; // Releases the view if it doesn't have a superview
	// Release anything that's not essential, such as cached data
}

//==========================================================================================
- (void)dealloc
{
	[super dealloc];
}

//==========================================================================================
- (IBAction) doneWithHelp:(id)sender
{
	[self.parentViewController dismissModalViewControllerAnimated:YES];
}

@end
