//
//  ofpAppDelegate_XMLStuff.h
//  onlineformapro
//
//  Created by Stephan on 04.03.09.
//  Copyright 2009 Coriolis Technologies. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "onlineformaproAppDelegate.h"

@interface onlineformaproAppDelegate (XMLStuff)

- (NSArray *) parseEvalListData:(NSData *)data;
- (NSArray *) parseQuestionsListData:(NSData *)data;
- (NSDictionary *) parseParcoursData:(NSData *)data;
- (NSDictionary *) parcoursDataForGUID:(NSString *)guid;
- (NSArray *) questionsListForGUID:(NSString *)guid;

@end
