//
//  ThemeViewController.h
//  onlineformapro
//
//  Created by Stephan on 02.03.09.
//  Copyright 2009 Coriolis Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface ThemeViewController : UIViewController {
	
	IBOutlet UITableView *tableView;
	NSIndexPath *selectedIndexPath;
	NSArray *themeList;
	

}

@property (nonatomic, retain) UITableView *tableView;
@property (nonatomic, retain) NSIndexPath *selectedIndexPath;
@property (nonatomic, retain) NSArray	*themeList;

@end
