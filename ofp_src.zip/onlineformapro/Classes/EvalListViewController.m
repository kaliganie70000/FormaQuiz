//
//  EvalListViewController.m
//  onlineformapro
//
//  Created by Stephan on 05.03.09.
//  Copyright 2009 Coriolis Technologies. All rights reserved.
//

#import "EvalListViewController.h"
#import "EvalListViewCell.h"
#import "DescriptifEvalViewController.h"


@implementation EvalListViewController

@synthesize tableView;
@synthesize	selectedIndexPath;
@synthesize evalList;
@synthesize sousThemeLabel;
@synthesize themeTitle;
@synthesize sousThemeTitle;

//==========================================================================================
- (void) viewDidLoad
{
	self.navigationController.navigationBar.tintColor = [UIColor blackColor];
	[super viewDidLoad];
}

//==========================================================================================
- (void)viewWillAppear:(BOOL)animated
{
	MARK;
	self.navigationItem.title = themeTitle;
	self.title = themeTitle;
	self.sousThemeLabel.text = sousThemeTitle;
	[self.tableView deselectRowAtIndexPath:selectedIndexPath animated:YES];
	[self.tableView reloadData];
	CMLog(@"evalList:%@", evalList);
	[super viewWillAppear:animated];
} 

//==========================================================================================
- (void)viewDidAppear:(BOOL)animated
{
	MARK;
	[super viewDidAppear:animated];
}

//==========================================================================================
- (void)viewWillDisappear:(BOOL)animated
{
	MARK;
	[super viewWillDisappear:animated];
}

//==========================================================================================
- (void)viewDidDisappear:(BOOL)animated   	 	 
{  	 	 
	self.navigationItem.title = @"Retour";
}

//==========================================================================================
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
	// Return YES for supported orientations
	return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

//==========================================================================================
- (void)didReceiveMemoryWarning
{
	[super didReceiveMemoryWarning]; // Releases the view if it doesn't have a superview
	// Release anything that's not essential, such as cached data
}

//==========================================================================================
- (void)dealloc
{
	MARK;
	[themeTitle release];
	[sousThemeTitle release];
	[sousThemeLabel release];
	[evalList release];
	[selectedIndexPath release];
	[tableView release];
	[super dealloc];
}

//==========================================================================================
#pragma mark UITableView delegate methods
//==========================================================================================
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView 
{
	return 1;
}

//==========================================================================================
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section 
{
	return [evalList count];
}

//==========================================================================================
- (UITableViewCell *)tableView:(UITableView *)tv cellForRowAtIndexPath:(NSIndexPath *)indexPath 
{
	EvalListViewCell *cell = (EvalListViewCell *)[tv dequeueReusableCellWithIdentifier:@"EvalListViewCell"];
	if (cell == nil) {
		UIViewController* c = [[UIViewController alloc] initWithNibName:@"EvalListViewCell" bundle:nil];
		cell = (EvalListViewCell *)c.view;
		cell.hidesAccessoryWhenEditing = NO;
		[c release];
	}

	NSDictionary *evaluation = [evalList objectAtIndex:indexPath.row];
	[cell.evalStatus setImage:NULL];
	cell.evalTitle.text = [evaluation objectForKey:@"titre"];
	cell.scoreLabel.hidden = TRUE;
	if ([[evaluation objectForKey:@"score"] length]) {
		cell.scoreLabel.text = [NSString stringWithFormat:@"%d/%d", [[evaluation objectForKey:@"score"] intValue],[[evaluation objectForKey:@"scoremax"] intValue]];
		cell.scoreLabel.hidden = FALSE;
		cell.evalStatus.hidden = TRUE;
	} else {
//	if ([[evaluation objectForKey:@"eval_done"] intValue] == 1) {
//		[cell.evalStatus setImage:[UIImage imageNamed:@"eval_done.png"]];
//	} else {
		if ([[evaluation objectForKey:@"eval_downloaded"] intValue] == 1) {
			[cell.evalStatus setImage:[UIImage imageNamed:@"eval_downloaded.png"]];
		}
	}
	CMLog(@"niveau: %d", [[evaluation objectForKey:@"niveau"] intValue]);
	switch ([[evaluation objectForKey:@"niveau"] intValue]) {
		case 1: [cell.evalLevel setImage:[UIImage imageNamed:@"level1.png"]];
			break;
		case 2: [cell.evalLevel setImage:[UIImage imageNamed:@"level2.png"]];
			break;
		case 3: [cell.evalLevel setImage:[UIImage imageNamed:@"level3.png"]];
			break;
		case 4: [cell.evalLevel setImage:[UIImage imageNamed:@"level4.png"]];
			break;
		case 5: [cell.evalLevel setImage:[UIImage imageNamed:@"level5.png"]];
			break;
		default: [cell.evalLevel setImage:nil];
			break;
	}
	cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
	
	// Set up the cell
	return cell;
}

//==========================================================================================
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
	NSMutableDictionary *evaluation = [evalList objectAtIndex:indexPath.row];
	self.selectedIndexPath = indexPath;
	DescriptifEvalViewController *viewController = [[DescriptifEvalViewController alloc] initWithNibName:@"DescriptifEvalViewController" bundle:nil];
	viewController.themeTitle = self.themeTitle;
	viewController.sousThemeTitle = self.sousThemeTitle;
	viewController.evaluation = evaluation;
	[self.navigationController pushViewController:viewController animated:YES];
	[viewController release];
}

@end