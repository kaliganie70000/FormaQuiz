//
//  InfoQuestionViewController.h
//  onlineformapro
//
//  Created by Stephan on 06.03.09.
//  Copyright 2009 Coriolis Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface InfoQuestionViewController : UIViewController {
	IBOutlet UIWebView *infoWebView;
	NSString *infoText;
	NSString *infoMedia;
	NSString *evalPath;
}

@property (nonatomic, retain) UIWebView *infoWebView;
@property (nonatomic, copy) NSString *infoMedia;
@property (nonatomic, copy) NSString *infoText;
@property (nonatomic, copy) NSString *evalPath;

- (IBAction) closeDialog:(id)sender;

@end
