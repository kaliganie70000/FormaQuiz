//
//  SousThemeViewController.h
//  onlineformapro
//
//  Created by Stephan on 05.03.09.
//  Copyright 2009 Coriolis Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface SousThemeViewController : UIViewController {

	IBOutlet UITableView *tableView;
	NSIndexPath *selectedIndexPath;
	NSString *themeTitle;
	NSArray *sousThemeList;
	
	
}

@property (nonatomic, retain) UITableView *tableView;
@property (nonatomic, retain) NSIndexPath *selectedIndexPath;
@property (nonatomic, retain) NSArray	*sousThemeList;
@property (nonatomic, copy) NSString *themeTitle;

@end