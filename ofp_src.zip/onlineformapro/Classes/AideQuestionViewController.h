//
//  AideQuestionViewController.h
//  onlineformapro
//
//  Created by Stephan on 06.03.09.
//  Copyright 2009 Coriolis Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface AideQuestionViewController : UIViewController {
	
	IBOutlet UITextView *aideTextView;

}

@property (nonatomic, retain) UITextView *aideTextView;

- (IBAction) closeDialog:(id)sender;

@end
