//
//  DataDownloader.m
//  onlineformapro
//
//  Created by Stephan on 02.02.09.
//  Copyright 2009 Coriolis Technologies. All rights reserved.
//

#import "DataDownloader.h"
#import "Reachability.h"

@implementation DataDownloader

@synthesize responseData;
@synthesize connectionError;
@synthesize dataURL;
@synthesize timeoutInterval;

//==========================================================================================
- (id)initWithDataURL:(NSString *)theDataURL
{
	if ((self = [super init])) {
		dataURL = [theDataURL retain];
		responseData    = nil;
		connectionError = nil;
		timeoutInterval = 60.0f;
		finished = NO;
	}
	return self;
}

//==========================================================================================
- (void)dealloc
{
	[connectionError release];
	[responseData release];
	[dataURL release];
	
	[super dealloc];
}

//==========================================================================================
- (NSData *)downloadWithErrorHandle:(NSError **)error
{
	NetworkStatus remoteHostStatus         = [[Reachability sharedReachability] remoteHostStatus];
	NetworkStatus internetConnectionStatus = [[Reachability sharedReachability] internetConnectionStatus];
	
//	CMLog(@"internetConnectionStatus: %d, remoteHostStatus: %d", internetConnectionStatus, remoteHostStatus);

	if ((internetConnectionStatus != NotReachable) || (remoteHostStatus != NotReachable)) {
		NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:dataURL] 
																													 cachePolicy:NSURLRequestReturnCacheDataElseLoad
																											 timeoutInterval:timeoutInterval];
		[request setValue:kUSER_AGENT forHTTPHeaderField:@"User-Agent"];
		[request setValue:@"gzip" forHTTPHeaderField:@"Accept-Encoding"];
		// Note: An NSOperation creates an autorelease pool, but doesn't schedule a run loop
		// Create the connection and schedule it on a run loop under our namespaced run mode
		NSURLConnection *connection = [[NSURLConnection alloc] initWithRequest:request delegate:self startImmediately:NO];
		[connection scheduleInRunLoop:[NSRunLoop currentRunLoop] forMode:DataDownloaderRunMode];
		[connection start];
		
		// Keep running the loop until the download has finished
		while (!finished) {			
			[[NSRunLoop currentRunLoop] runMode:DataDownloaderRunMode
															 beforeDate:[NSDate dateWithTimeIntervalSinceNow:30.0]];
		}
		[connection release];
		
		// If there was an error, set it to the passed in error handle
		if (connectionError) {
			if (error) { // However, set it only if a valid error handle was passed in (i.e., not nil)
				*error = connectionError;
			}
			return nil;
		}
	}

//	CMLog(@"response: %@", [[[NSString alloc] initWithData:responseData encoding:NSUTF8StringEncoding] autorelease]);
	return responseData;
}

#pragma mark -
#pragma mark NSURLConnection Delegate Methods

//==========================================================================================
- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
//	CMLog(@"response Mime: %@", [response MIMEType]);
//	CMLog(@"response textEncodingName: %@", [response textEncodingName]);
	responseData = [[NSMutableData alloc] initWithLength:0];
}

//==========================================================================================
- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
	[responseData appendData:data];
}

//==========================================================================================
- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
	MARK;
	connectionError = [error retain];
	
	finished = YES;
}

//==========================================================================================
- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
	finished = YES;
}

@end
