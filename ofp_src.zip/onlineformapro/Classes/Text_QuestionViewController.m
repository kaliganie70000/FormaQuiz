//
//  Text_QuestionViewController.m
//  onlineformapro
//
//  Created by Stephan on 07.03.09.
//  Copyright 2009 Coriolis Technologies. All rights reserved.
//

#import "Text_QuestionViewController.h"


@implementation Text_QuestionViewController

@synthesize textField;
@synthesize questionImageView;
@synthesize answerLabel;
@synthesize question;
@synthesize evalPath;

//==========================================================================================
- (void)viewDidLoad
{
	textField.clearButtonMode = UITextFieldViewModeWhileEditing;
	textField.text = @"";
	[super viewDidLoad];
}

//==========================================================================================
- (void) viewWillAppear:(BOOL)animated
{
	MARK;	

	NSString *media = [question objectForKey:@"consigneMedia"];
	questionImageView.hidden = YES;
	if ([media length]) {
		NSString *mediaPath = [NSString stringWithFormat:@"%@/%@", evalPath, media];
		NSData *data = [NSData dataWithContentsOfFile:mediaPath];
		if (data) {
			UIImage *image = [UIImage imageWithData:data];
			questionImageView.image = image;
			questionImageView.hidden = NO;
		}
	}
	answerLabel.hidden = YES;
}

//==========================================================================================
- (NSNumber *) isAnswerValid
{
	BOOL valid = FALSE;
	NSArray *validAnswers = [[question objectForKey:@"solutions"] componentsSeparatedByString:@"*^*"];
	for (NSString *answer in validAnswers) {
		if ([[textField.text lowercaseString] rangeOfString:[answer lowercaseString]].location != NSNotFound) {
			valid = TRUE;
		}
	}
	return [NSNumber numberWithBool:valid];
}

//==========================================================================================
- (void) displayValidAnswer
{
	NSString *answer = [[[question objectForKey:@"solutions"] componentsSeparatedByString:@"*^*"] objectAtIndex:0];
	answerLabel.text = answer;
	answerLabel.hidden = FALSE;
	if ([[self isAnswerValid] boolValue]) {
		questionImageView.image = [UIImage imageNamed:@"valid_glow.png"];
	} else {
		questionImageView.image = [UIImage imageNamed:@"redhand_glow.png"];
	}
	questionImageView.hidden = NO;
	textField.userInteractionEnabled = NO;
}

//==========================================================================================
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
	// Return YES for supported orientations
	return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

//==========================================================================================
- (void)didReceiveMemoryWarning
{
	[super didReceiveMemoryWarning]; // Releases the view if it doesn't have a superview
	// Release anything that's not essential, such as cached data
}

//==========================================================================================
- (void)dealloc
{
	MARK;
	[textField release];
	[questionImageView release];
	[answerLabel release];
	[question release];
	[evalPath release];
	[super dealloc];
}

//==========================================================================================
- (BOOL)textFieldShouldReturn:(UITextField *)_textField
{
	MARK;
	[_textField resignFirstResponder];
	return YES;
}

@end
