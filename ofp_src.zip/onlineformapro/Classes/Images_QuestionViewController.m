//
//  Images_QuestionViewController.m
//  onlineformapro
//
//  Created by Stephan on 07.03.09.
//  Copyright 2009 Coriolis Technologies. All rights reserved.
//

#import "Images_QuestionViewController.h"


@implementation Images_QuestionViewController

@synthesize image1View;
@synthesize image2View;
@synthesize image3View;
@synthesize image4View;
@synthesize button1;
@synthesize button2;
@synthesize button3;
@synthesize button4;
@synthesize question;
@synthesize evalPath;

//==========================================================================================
- (IBAction) buttonClicked:(id)sender
{
	CMLog(@"Clicked: %d", [sender tag]);
//	button1.selected = NO;
//	button1.selected = NO;
//	button1.selected = NO;
//	button1.selected = NO;
	UIButton *button = (UIButton *) sender;
	button.selected = !button.selected;
}

//==========================================================================================
- (void)viewDidLoad
{
	[super viewDidLoad];
}

//==========================================================================================
- (void) viewWillAppear:(BOOL)animated
{
	MARK;	
	CMLog(@"propositions: %@", [question objectForKey:@"propositions"]);
	NSArray *questionList = [[question objectForKey:@"propositions"] componentsSeparatedByString:@"*^*"];
	CMLog(@"questionList: %@", questionList)
	if ([[questionList objectAtIndex:3] length] == 0) {
		button4.hidden = YES;
		image4View.hidden = YES;
	} else {
		NSString *mediaPath = [NSString stringWithFormat:@"%@/%@", evalPath, [questionList objectAtIndex:3]];
		NSData *data = [NSData dataWithContentsOfFile:mediaPath];
		if (data) {
			UIImage *image = [UIImage imageWithData:data];
			image4View.image = image;
		}
	}
	if ([[questionList objectAtIndex:2] length] == 0) {
		button3.hidden = YES;
		image3View.hidden = YES;
	} else {
		NSString *mediaPath = [NSString stringWithFormat:@"%@/%@", evalPath, [questionList objectAtIndex:2]];
		NSData *data = [NSData dataWithContentsOfFile:mediaPath];
		if (data) {
			UIImage *image = [UIImage imageWithData:data];
			image3View.image = image;
		}
	}
	if ([[questionList objectAtIndex:1] length] == 0) {
		button2.hidden = YES;
		image2View.hidden = YES;
	} else {
		NSString *mediaPath = [NSString stringWithFormat:@"%@/%@", evalPath, [questionList objectAtIndex:1]];
		NSData *data = [NSData dataWithContentsOfFile:mediaPath];
		if (data) {
			UIImage *image = [UIImage imageWithData:data];
			image2View.image = image;
		}
	}
	NSString *mediaPath = [NSString stringWithFormat:@"%@/%@", evalPath, [questionList objectAtIndex:0]];
	NSData *data = [NSData dataWithContentsOfFile:mediaPath];
	if (data) {
		UIImage *image = [UIImage imageWithData:data];
		image1View.image = image;
	}
	
}

//==========================================================================================
- (NSNumber *) isAnswerValid
{
	BOOL valid = TRUE;
	NSArray *answerList = [[question objectForKey:@"solutions"] componentsSeparatedByString:@"*^*"];
	if ([[answerList objectAtIndex:0] isEqualToString:@"true"]) {
		if (!button1.selected)
			valid = FALSE;
	}
	if ([[answerList objectAtIndex:1] isEqualToString:@"true"]) {
		if (!button2.selected)
			valid = FALSE;
	}
	if ([[answerList objectAtIndex:2] isEqualToString:@"true"]) {
		if (!button3.selected)
			valid = FALSE;
	}
	if ([[answerList objectAtIndex:3] isEqualToString:@"true"]) {
		if (!button4.selected)
			valid = FALSE;
	}
	return [NSNumber numberWithBool:valid];
}

//==========================================================================================
- (void) displayValidAnswer
{
	BOOL expectedState;
	NSArray *answerList = [[question objectForKey:@"solutions"] componentsSeparatedByString:@"*^*"];
	expectedState = [[answerList objectAtIndex:0] isEqualToString:@"true"];
	if (expectedState == TRUE) {
		[button1 setBackgroundImage:[UIImage imageNamed:@"valid_glow.png"] forState:UIControlStateSelected];
		[button1 setBackgroundImage:[UIImage imageNamed:@"valid_noglow.png"] forState:UIControlStateNormal];
	} else {
		if (button1.selected != expectedState) {
			button1.selected = FALSE;
			[button1 setBackgroundImage:[UIImage imageNamed:@"redhand_glow.png"] forState:UIControlStateNormal];
		}
	}
	expectedState = [[answerList objectAtIndex:1] isEqualToString:@"true"];
	if (expectedState == TRUE) {
		[button2 setBackgroundImage:[UIImage imageNamed:@"valid_glow.png"] forState:UIControlStateSelected];
		[button2 setBackgroundImage:[UIImage imageNamed:@"valid_noglow.png"] forState:UIControlStateNormal];
	} else {
		if (button2.selected != expectedState) {
			button2.selected = FALSE;
			[button2 setBackgroundImage:[UIImage imageNamed:@"redhand_glow.png"] forState:UIControlStateNormal];
		}
	}
	expectedState = [[answerList objectAtIndex:2] isEqualToString:@"true"];
	if (expectedState == TRUE) {
		[button3 setBackgroundImage:[UIImage imageNamed:@"valid_glow.png"] forState:UIControlStateSelected];
		[button3 setBackgroundImage:[UIImage imageNamed:@"valid_noglow.png"] forState:UIControlStateNormal];
	} else {
		if (button3.selected != expectedState) {
			button3.selected = FALSE;
			[button3 setBackgroundImage:[UIImage imageNamed:@"redhand_glow.png"] forState:UIControlStateNormal];
		}
	}
	expectedState = [[answerList objectAtIndex:3] isEqualToString:@"true"];
	if (expectedState == TRUE) {
		[button4 setBackgroundImage:[UIImage imageNamed:@"valid_glow.png"] forState:UIControlStateSelected];
		[button4 setBackgroundImage:[UIImage imageNamed:@"valid_noglow.png"] forState:UIControlStateNormal];
	} else {
		if (button4.selected != expectedState) {
			button4.selected = FALSE;
			[button4 setBackgroundImage:[UIImage imageNamed:@"redhand_glow.png"] forState:UIControlStateNormal];
		}
	}
	button1.userInteractionEnabled = NO;
	button2.userInteractionEnabled = NO;
	button3.userInteractionEnabled = NO;
	button4.userInteractionEnabled = NO;
}

//==========================================================================================
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
	// Return YES for supported orientations
	return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

//==========================================================================================
- (void)didReceiveMemoryWarning
{
	[super didReceiveMemoryWarning]; // Releases the view if it doesn't have a superview
	// Release anything that's not essential, such as cached data
}

//==========================================================================================
- (void)dealloc
{
	MARK;
	[image1View release];
	[image2View release];
	[image3View release];
	[image4View release];
	[button1 release];
	[button2 release];
	[button3 release];
	[button4 release];
	[question release];
	[evalPath release];
	[super dealloc];
}

@end
