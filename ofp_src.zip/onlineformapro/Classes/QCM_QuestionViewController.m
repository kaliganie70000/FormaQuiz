//
//  QCM_QuestionViewController.m
//  onlineformapro
//
//  Created by Stephan on 06.03.09.
//  Copyright 2009 Coriolis Technologies. All rights reserved.
//

#import "QCM_QuestionViewController.h"


@implementation QCM_QuestionViewController

@synthesize answer1Button;
@synthesize answer2Button;
@synthesize answer3Button;
@synthesize answer4Button;
@synthesize questionImageView;
@synthesize answer1Label;
@synthesize answer2Label;
@synthesize answer3Label;
@synthesize answer4Label;
@synthesize question;
@synthesize evalPath;
@synthesize qcm;

//==========================================================================================
- (IBAction) touchDown:(UIButton *)sender
{
	MARK;
	BOOL selected = [(UIButton *)sender isSelected];
	if (selected) {
		[sender setImage:[UIImage imageNamed:@"qcm_btn_pressed_empty.png"] forState:UIControlStateNormal];
	} else {
		[sender setImage:[UIImage imageNamed:@"qcm_btn_pressed_checked.png"] forState:UIControlStateHighlighted];
	}
}

//==========================================================================================
- (IBAction) buttonClicked:(id)sender
{
	MARK;
	CMLog(@"Clicked: %d", [sender tag]);
	if (!qcm) {
		answer1Button.selected = NO;
		answer2Button.selected = NO;
		answer3Button.selected = NO;
		answer4Button.selected = NO;
	}
	[(UIButton *)sender setImage:[UIImage imageNamed:@"qcm_btn_off.png"] forState:UIControlStateNormal];
	[(UIButton *)sender setSelected:![sender isSelected]];
}

//==========================================================================================
- (void)viewDidLoad
{
	[super viewDidLoad];
}

//==========================================================================================
- (void) viewWillAppear:(BOOL)animated
{
	MARK;	
	CMLog(@"propositions: %@", [question objectForKey:@"propositions"]);
	NSArray *questionList = [[question objectForKey:@"propositions"] componentsSeparatedByString:@"*^*"];
	CMLog(@"questionList: %@", questionList)
	if ([[questionList objectAtIndex:3] length] == 0) {
		answer4Button.hidden = YES;
		answer4Label.hidden = YES;
	}
	if ([[questionList objectAtIndex:2] length] == 0) {
		answer3Button.hidden = YES;
		answer3Label.hidden = YES;
	}
	if ([[questionList objectAtIndex:1] length] == 0) {
		answer2Button.hidden = YES;
		answer2Label.hidden = YES;
	}

	NSString *media = [question objectForKey:@"consigneMedia"];
	questionImageView.hidden = YES;
	if ([media length]) {
		NSString *mediaPath = [NSString stringWithFormat:@"%@/%@", evalPath, media];
		NSData *data = [NSData dataWithContentsOfFile:mediaPath];
		if (data) {
			UIImage *image = [UIImage imageWithData:data];
			questionImageView.image = image;
			questionImageView.hidden = NO;
		}
	}
	answer1Label.text = [NSString stringWithFormat:@"%@", [questionList objectAtIndex:0]];
	answer2Label.text = [NSString stringWithFormat:@"%@", [questionList objectAtIndex:1]];
	answer3Label.text = [NSString stringWithFormat:@"%@", [questionList objectAtIndex:2]];
	answer4Label.text = [NSString stringWithFormat:@"%@", [questionList objectAtIndex:3]];
}

//==========================================================================================
- (NSNumber *) isAnswerValid
{
	BOOL valid = TRUE;
	NSArray *answerList = [[question objectForKey:@"solutions"] componentsSeparatedByString:@"*^*"];
	if ([[answerList objectAtIndex:0] isEqualToString:@"true"]) {
		if (!answer1Button.selected)
			valid = FALSE;
	}
	if ([[answerList objectAtIndex:1] isEqualToString:@"true"]) {
		if (!answer2Button.selected)
			valid = FALSE;
	}
	if ([[answerList objectAtIndex:2] isEqualToString:@"true"]) {
		if (!answer3Button.selected)
			valid = FALSE;
	}
	if ([[answerList objectAtIndex:3] isEqualToString:@"true"]) {
		if (!answer4Button.selected)
			valid = FALSE;
	}
	return [NSNumber numberWithBool:valid];
}

//==========================================================================================
- (void) displayValidAnswer
{
	BOOL expectedState;
	NSArray *answerList = [[question objectForKey:@"solutions"] componentsSeparatedByString:@"*^*"];
	expectedState = [[answerList objectAtIndex:0] isEqualToString:@"true"];
	if (expectedState == TRUE) {
//		answer1Label.backgroundColor = [UIColor colorWithRed:(1.0f/255.0f) green:(128.0f/255.0f) blue:(64.0f/255.0f) alpha:1.0f];
		answer1Button.selected = FALSE;
		answer1Label.textColor = [UIColor blackColor];
		[answer1Button setImage:[UIImage imageNamed:@"qcm_btn_pressed_checked.png"] forState:UIControlStateNormal];
	} else {
		if (answer1Button.selected != expectedState) {
			answer1Label.textColor = [UIColor redColor];
			answer1Button.selected = FALSE;
			[answer1Button setImage:[UIImage imageNamed:@"qcm_btn_wrong.png"] forState:UIControlStateNormal];
		}
	}
	expectedState = [[answerList objectAtIndex:1] isEqualToString:@"true"];
	if (expectedState == TRUE) {
		answer2Button.selected = FALSE;
		answer2Label.textColor = [UIColor blackColor];
		[answer2Button setImage:[UIImage imageNamed:@"qcm_btn_pressed_checked.png"] forState:UIControlStateNormal];
	} else {
		if (answer2Button.selected != expectedState) {
			answer2Label.textColor = [UIColor redColor];
			answer2Button.selected = FALSE;
			[answer2Button setImage:[UIImage imageNamed:@"qcm_btn_wrong.png"] forState:UIControlStateNormal];
		}
	}
	expectedState = [[answerList objectAtIndex:2] isEqualToString:@"true"];
	if (expectedState == TRUE) {
		answer3Button.selected = FALSE;
		answer3Label.textColor = [UIColor blackColor];
		[answer3Button setImage:[UIImage imageNamed:@"qcm_btn_pressed_checked.png"] forState:UIControlStateNormal];
	} else {
		if (answer3Button.selected != expectedState) {
			answer3Button.selected = FALSE;
			answer3Label.textColor = [UIColor redColor];
			[answer3Button setImage:[UIImage imageNamed:@"qcm_btn_wrong.png"] forState:UIControlStateNormal];
		}
	}
	expectedState = [[answerList objectAtIndex:3] isEqualToString:@"true"];
	if (expectedState == TRUE) {
		answer4Button.selected = FALSE;
		answer4Label.textColor = [UIColor blackColor];
		[answer4Button setImage:[UIImage imageNamed:@"qcm_btn_pressed_checked.png"] forState:UIControlStateNormal];
	} else {
		if (answer4Button.selected != expectedState) {
			answer4Button.selected = FALSE;
			answer4Label.textColor = [UIColor redColor];
			[answer4Button setImage:[UIImage imageNamed:@"qcm_btn_wrong.png"] forState:UIControlStateNormal];
		}
	}
	answer4Button.userInteractionEnabled = NO;
	answer3Button.userInteractionEnabled = NO;
	answer2Button.userInteractionEnabled = NO;
	answer1Button.userInteractionEnabled = NO;
}

//==========================================================================================
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
	// Return YES for supported orientations
	return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

//==========================================================================================
- (void)didReceiveMemoryWarning
{
	[super didReceiveMemoryWarning]; // Releases the view if it doesn't have a superview
	// Release anything that's not essential, such as cached data
}

//==========================================================================================
- (void)dealloc
{
	MARK;
	[answer1Button release];
	[answer2Button release];
	[answer3Button release];
	[answer4Button release];
	[questionImageView release];
	[answer1Label release];
	[answer2Label release];
	[answer3Label release];
	[answer4Label release];
	[question release];
	[evalPath release];
	[super dealloc];
}

@end
