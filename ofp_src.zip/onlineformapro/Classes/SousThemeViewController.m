//
//  SousThemeViewController.m
//  onlineformapro
//
//  Created by Stephan on 05.03.09.
//  Copyright 2009 Coriolis Technologies. All rights reserved.
//

#import "SousThemeViewController.h"
#import "EvalListViewController.h"


@implementation SousThemeViewController

@synthesize tableView;
@synthesize	selectedIndexPath;
@synthesize sousThemeList;
@synthesize themeTitle;

//==========================================================================================
- (void) viewDidLoad
{
	self.navigationController.navigationBar.tintColor = [UIColor blackColor];
	[super viewDidLoad];
}

//==========================================================================================
- (void)viewWillAppear:(BOOL)animated
{
	MARK;
//	self.title = themeTitle;
	self.navigationItem.title = themeTitle;
	[self.tableView deselectRowAtIndexPath:selectedIndexPath animated:YES];
	[self.tableView reloadData];
	[super viewWillAppear:animated];
} 

//==========================================================================================
- (void)viewDidAppear:(BOOL)animated
{
	MARK;
	[super viewDidAppear:animated];
}

//==========================================================================================
- (void)viewWillDisappear:(BOOL)animated
{
	MARK;
	[super viewWillDisappear:animated];
}

//==========================================================================================
- (void)viewDidDisappear:(BOOL)animated   	 	 
{  	 	 
	self.navigationItem.title = @"Retour";
}

//==========================================================================================
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
	// Return YES for supported orientations
	return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

//==========================================================================================
- (void)didReceiveMemoryWarning
{
	[super didReceiveMemoryWarning]; // Releases the view if it doesn't have a superview
	// Release anything that's not essential, such as cached data
}

//==========================================================================================
- (void)dealloc
{
	MARK;
	[sousThemeList release];
	[selectedIndexPath release];
	[tableView release];
	[super dealloc];
}

//==========================================================================================
#pragma mark UITableView delegate methods
//==========================================================================================
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView 
{
	return 1;
}

//==========================================================================================
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section 
{
	return [sousThemeList count];
}

//==========================================================================================
- (UITableViewCell *)tableView:(UITableView *)tv cellForRowAtIndexPath:(NSIndexPath *)indexPath 
{
	UITableViewCell *cell = [tv dequeueReusableCellWithIdentifier:@"sousThemeListCell"];
	if (cell == nil) {
		cell = [[[UITableViewCell alloc] initWithFrame:CGRectZero reuseIdentifier:@"sousThemeListCell"] autorelease];
	}

	cell.text = [[sousThemeList objectAtIndex:indexPath.row] objectForKey:@"titre"];
	cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
	
	// Set up the cell
	return cell;
}

//==========================================================================================
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
	NSArray *evalList = [[sousThemeList objectAtIndex:indexPath.row] objectForKey:@"evaluation"];
	self.selectedIndexPath = indexPath;
	EvalListViewController *viewController = [[EvalListViewController alloc] initWithNibName:@"EvalListViewController" bundle:nil];
	viewController.themeTitle = self.themeTitle;
	viewController.sousThemeTitle = [[sousThemeList objectAtIndex:indexPath.row] objectForKey:@"titre"];
	viewController.evalList = evalList;
	[self.navigationController pushViewController:viewController animated:YES];
	[viewController release];
}

@end