//
//  onlineformaproAppDelegate.m
//  onlineformapro
//
//  Created by Stephan on 23.02.09.
//  Copyright Coriolis Technologies 2009. All rights reserved.
//

#import "onlineformaproAppDelegate.h"
#import "ofpAppDelegate_XMLStuff.h"
#import "DataDownloader.h"
#import "MainViewController.h"
#import "FFArchiveZIP.h"
#import "Reachability.h"

@implementation NSString ( myCompare )
-(NSComparisonResult) compareWithNumericSearch: (NSString *) aString; {
	return [self compare: aString options: NSNumericSearch];
}
@end


@interface NSString ( myCompare )
-(NSComparisonResult) compareWithNumericSearch: (NSString *) aString;
@end

@implementation onlineformaproAppDelegate

@synthesize window;
@synthesize documentsPath;
@synthesize sendResultURL;
@synthesize navigationController;

//==========================================================================================
- (void) redirectConsoleLogToDocumentFolder
{
	NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, 
																											 NSUserDomainMask, YES);
	NSString *documentsDirectory = [paths objectAtIndex:0];
	NSString *logPath = [documentsDirectory 
											 stringByAppendingPathComponent:@"console.log"];
	freopen([logPath cStringUsingEncoding:NSASCIIStringEncoding],"a+",stderr);
	//	freopen([logPath cStringUsingEncoding:NSASCIIStringEncoding],"a+",stdout);
}

//==========================================================================================
- (void)applicationDidFinishLaunching:(UIApplication *)application
{

#if	TARGET_IPHONE_SIMULATOR
	
#else
//	[self redirectConsoleLogToDocumentFolder];
#endif

	[NSString stringWithContentsOfURL:[NSURL URLWithString:@"http://www.google.com/robots.txt"]];
	[[Reachability sharedReachability] setHostName:@"www.google.com"];
	[[UIApplication sharedApplication] setStatusBarHidden:YES];
	[self initializeUserDefaults];

	NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
	self.documentsPath = [paths objectAtIndex:0];

	// Override point for customization after application launch
	NSURLCache *sharedCache = [[NSURLCache alloc] initWithMemoryCapacity:0 diskCapacity:0 diskPath:nil];
	[NSURLCache setSharedURLCache:sharedCache];
	[sharedCache release];

	MainViewController *mainViewController = [[MainViewController alloc] initWithNibName:@"MainViewController" bundle:nil];
	navigationController = [[UINavigationController alloc] initWithRootViewController:mainViewController];
	// Configure and show the window
	navigationController.navigationBarHidden = YES;
	[window addSubview:[navigationController view]];
	[mainViewController release];
	[window makeKeyAndVisible];
}

//==========================================================================================
- (void)initializeUserDefaults
{
	NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
	
	NSDictionary* dict = [NSDictionary dictionaryWithObjectsAndKeys:
												 @"",                             kPREF_USER,
												 @"",                             kPREF_PWD,
												 @"0000",													kPREF_CLIENT,
												 [NSNumber numberWithBool:true],	kPREF_PLAYSOUND,
												 [NSNumber numberWithBool:true],	kPREF_SHOWANSWERS,
												 [NSNumber numberWithFloat:0.5f],	kPREF_SOUNDVOLUME,
												 nil];
	
	for (id key in dict) {
		if ([defaults objectForKey:key] == nil) {
			[defaults setObject:[dict objectForKey:key] forKey:key];
		}
	}
	[defaults synchronize];
}

//==========================================================================================
- (void)applicationWillTerminate:(UIApplication *)application
{
	FMDatabase *ofp_DB = [[OFPDatabase sharedInstance] ofp_DB];
	[ofp_DB close];
}

//==========================================================================================
- (void)applicationDidReceiveMemoryWarning:(UIApplication *)application
{
	MARK;
	FMDatabase *ofp_DB = [[OFPDatabase sharedInstance] ofp_DB];
	[ofp_DB close];
	[ofp_DB open];
	[ofp_DB executeUpdate:@"PRAGMA cache_size=5"];
}

//==========================================================================================
- (void) sendRemainingResultsToServer
{
	MARK;
	FMDatabase *ofp_DB = [[OFPDatabase sharedInstance] ofp_DB];
	
	FMResultSet *rs = [ofp_DB executeQuery:@"SELECT * from resultats"];
	NSMutableArray *sentResults = [NSMutableArray array];
	while ([rs next]) {
		NSString *guid = [rs stringForColumn:@"guid"];
		NSString *data = [rs stringForColumn:@"data"];
		if ([self sendResultatToServer:data]) {
			[sentResults addObject:guid];
		}
	}
	[rs close];
	for (NSString *guid in sentResults) {
		[ofp_DB executeUpdate:@"DELETE FROM resultats WHERE guid = ?", guid];
		[ofp_DB executeUpdate :@"DELETE FROM evaluation WHERE guid = ?", guid];
	}
}

//==========================================================================================
- (void)dealloc
{
	[window release];
	[super dealloc];
}

//==========================================================================================
- (NSString *)getSendResultURLFromServer:(NSString *)serverData
{
	NSString *responseURL = nil;
	
	NSScanner *scanner = [NSScanner scannerWithString:serverData];
	if ([scanner scanUpToString:@"<url>" intoString:NULL]) {
		[scanner scanString:@"<url>" intoString:NULL];
		[scanner scanUpToString:@"</url>" intoString:&responseURL];
	}
	return responseURL;
}

//==========================================================================================
- (NSInteger)statusFromServer:(NSString *)serverData
{
	NSInteger status = 0;
	
	NSScanner *scanner = [NSScanner scannerWithString:serverData];
	if ([scanner scanUpToString:@"<status>" intoString:NULL]) {
		[scanner scanString:@"<status>" intoString:NULL];
		[scanner scanInteger:&status];
	}
	return status;
}

//==========================================================================================
- (NSString *)errorFromServer:(NSString *)serverData
{
	NSString *errorMsg = nil;
	
	NSScanner *scanner = [NSScanner scannerWithString:serverData];
	if ([scanner scanUpToString:@"<error_msg>" intoString:NULL]) {
		[scanner scanString:@"<error_msg>" intoString:NULL];
		[scanner scanUpToString:@"</error_msg>" intoString:&errorMsg];
	}
	return errorMsg;
}

//==========================================================================================
- (void) logout
{
	START_TIMER;
	NSMutableURLRequest *request = [[NSMutableURLRequest alloc] initWithURL:[NSURL URLWithString: kLOGOUT_URL]];
	request.timeoutInterval = 10.0f;
	CMLog(@"timeout: %.2f", request.timeoutInterval);
	[NSURLConnection sendSynchronousRequest:request returningResponse:nil error: nil];
	[request release];
	END_TIMER(@"logout");
}

//==========================================================================================
- (BOOL)loginWithStoredUserAndPassword
{
	MARK;
	NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
	NSString *username = [defaults objectForKey:kPREF_USER];
	NSString *password = [defaults objectForKey:kPREF_PWD];
	NSString *clientID = [defaults objectForKey:kPREF_CLIENT];
	return [self loginWithUser:username password:password client:clientID];
}

//==========================================================================================
- (BOOL) sendResultatToServer:(NSString *)resultat
{
	BOOL result = FALSE;
	[self logout];
	if ([self loginWithStoredUserAndPassword]) {
		
		if (self.sendResultURL) {
			CMLog(@"resultat: %@", resultat);
			NSString *requestString = [NSString stringWithFormat:@"handler=EvalIphone&method=PostResult&codexml=%@", [resultat stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
			NSData *myRequestData = [NSData dataWithBytes:[requestString UTF8String] length:[requestString length]];
			NSMutableURLRequest *request = [[NSMutableURLRequest alloc] initWithURL:[NSURL URLWithString: sendResultURL]];
			[request setHTTPMethod: @"POST"];
			[request setHTTPBody: myRequestData];
			[request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"content-type"];
			NSURLResponse *response;
			NSData *returnData = [NSURLConnection sendSynchronousRequest: request returningResponse: &response error: nil];
			if (returnData != NULL) {
				NSString *responseString = [[[NSString alloc] initWithData:returnData encoding:NSUTF8StringEncoding] autorelease];
				CMLog(@"received: %@", responseString);
				NSInteger status = [self statusFromServer:responseString];
				if (status == 200) {
					result = TRUE;
				} else {
					NSString *error = [self errorFromServer:responseString];
					if (error) {
						UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Erreur" 
																														message:error delegate:nil 
																									cancelButtonTitle:@"OK" 
																									otherButtonTitles:nil];
						[alert show];
						[alert release];
					}
				}
			} else {
				CMLog(@"received no data");
			}
			[request release];
		} else {
			UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Erreur" 
																											message:@"Paramètre 'url' manque dans la réponse au login."
																										 delegate:nil 
																						cancelButtonTitle:@"OK" 
																						otherButtonTitles:nil];
			[alert show];
			[alert release];
		}
	}
	return result;
}

//==========================================================================================
- (BOOL) loginWithUser:(NSString *)username password:(NSString *)password client:(NSString *)clientID;
{
	BOOL result = FALSE;

	START_TIMER;
	[self logout];
	CMLog(@"user: %@, pwd: %@", username, password);
	NSString *requestString = [NSString stringWithFormat:@"%@&login=%@&password=%@&client=%@", kLOGIN_URL, username, password, clientID];
	CMLog(@"requestString: %@", requestString);
//	NSData *myRequestData = [NSData dataWithBytes:[requestString UTF8String] length:[requestString length]];
	NSMutableURLRequest *request = [[NSMutableURLRequest alloc] initWithURL:[NSURL URLWithString: requestString]];
	request.timeoutInterval = 10.0f;
//	[request setHTTPMethod: @"POST"];
//	[request setHTTPBody: myRequestData];
//	[request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"content-type"];
	NSURLResponse *response;
	NSData *returnData = [NSURLConnection sendSynchronousRequest: request returningResponse: &response error: nil];
	if (returnData != NULL) {
		NSString *responseString = [[[NSString alloc] initWithData:returnData encoding:NSUTF8StringEncoding] autorelease];
		CMLog(@"received: %@", responseString);
		NSInteger status = [self statusFromServer:responseString];
		if (status == 200) {
			self.sendResultURL = [self getSendResultURLFromServer:responseString];
			result = TRUE;
		} else {
			NSString *error = [self errorFromServer:responseString];
			if (error) {
				UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Erreur"
																												message:error
																											 delegate:nil 
																							cancelButtonTitle:@"OK" 
																							otherButtonTitles:nil];
				[alert show];
				[alert release];
			}
		}
	} else {
		CMLog(@"received no data");
	}

	[request release];
	END_TIMER(@"loginWithUser");
	return result;
}

//==========================================================================================
- (void) cleanupData:(NSArray *)evalList
{
	NSFileManager *fm = [NSFileManager defaultManager];
	NSMutableArray *guidList = [NSMutableArray array];
	for (NSDictionary *theme in evalList) {
		for (NSDictionary *stheme in [theme objectForKey:@"soustheme"]) {
			for (NSDictionary *eval in [stheme objectForKey:@"evaluation"]) {
				[guidList addObject:[eval objectForKey:@"guid"]];
			}
		}
	}
	CMLog(@"guidList: %@", guidList);
	NSArray *fileList = [fm directoryContentsAtPath:self.documentsPath];
	for (NSString *filename in fileList) {
		NSString *path = [NSString stringWithFormat:@"%@/%@", documentsPath, filename];
		BOOL isDirectory;
		if ([fm fileExistsAtPath:path isDirectory:&isDirectory] && isDirectory) {
			if ([guidList indexOfObject:filename] == NSNotFound) {
				CMLog(@"SHould delete %@", path);
				[fm removeItemAtPath:path error:nil];
			} else {
				CMLog(@"SHould NOT delete %@", path);
			}
		}
	}
}

//==========================================================================================
- (NSArray *) evalListFromServer
{
	START_TIMER;
	NSArray *evalList = NULL;
	NSMutableURLRequest *request = [[NSMutableURLRequest alloc] initWithURL:[NSURL URLWithString: kEVAL_LIST_URL]];
	request.timeoutInterval = 10.0f;
	NSData *returnData = [NSURLConnection sendSynchronousRequest: request returningResponse:nil error: nil];
	if (returnData != NULL) {
		NSString *responseString = [[[NSString alloc] initWithData:returnData encoding:NSUTF8StringEncoding] autorelease];
		CMLog(@"received: %@", responseString);
		NSInteger status = [self statusFromServer:responseString];
		if (status != 200) {
			NSString *errorMsg = [self errorFromServer:responseString];
			UIAlertView *alert = [[UIAlertView alloc] initWithTitle: @"Erreur"
																											message:[NSString stringWithFormat:@"Erreur lors du chargement de la liste des évaluations.", errorMsg] 
																										 delegate:nil 
																						cancelButtonTitle:@"OK" 
																						otherButtonTitles:nil];
			[alert show];
			[alert release];
		} else {
			evalList = [self parseEvalListData:returnData];
			if (evalList && ([evalList count])) {
				NSString *evalPath = [NSString stringWithFormat:@"%@/eval_list.xml", [UIAppDelegate documentsPath]];
				[evalList writeToFile:evalPath atomically:NO];
				evalList = [self postProcessEvalList:evalList];
				[self cleanupData:evalList];
			} else {
				UIAlertView *alert = [[UIAlertView alloc] initWithTitle: @"Erreur"
																												message:@"Il n'y a pas d'évaluations pour cet utilisateur."
																											 delegate:nil 
																							cancelButtonTitle:@"OK" 
																							otherButtonTitles:nil];
				[alert show];
				[alert release];
			}
		}
	} else {
		CMLog(@"received no data");
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Erreur" 
																										message:@"Erreur lors du chargement de la liste des évaluations. (Pas de données)" 
																									 delegate:nil 
																					cancelButtonTitle:@"OK" 
																					otherButtonTitles:nil];
		[alert show];
		[alert release];
	}
	[request release];
	END_TIMER(@"evalListFromServer");
	return evalList;
}

//==========================================================================================
- (NSArray *) postProcessEvalList:(NSArray *)evalList
{
	FMDatabase *db = [[OFPDatabase sharedInstance] ofp_DB];
	
	CMLog(@"evalList: %@", evalList);
	for (NSDictionary *theme in evalList) {
		for (NSMutableDictionary *soustheme in [theme objectForKey:@"soustheme"]) {
			for (NSMutableDictionary *evaluation in [soustheme objectForKey:@"evaluation"]) {
				NSString *guid = [evaluation objectForKey:@"guid"];
				NSString *evalPath = [NSString stringWithFormat:@"%@/%@", self.documentsPath, guid];
				if ([[NSFileManager defaultManager] fileExistsAtPath:evalPath]) {
					[evaluation setObject:[NSNumber numberWithInt:1] forKey:@"eval_downloaded"];
				} else {
					[evaluation setObject:[NSNumber numberWithInt:0] forKey:@"eval_downloaded"];
				}
				if ([[evaluation objectForKey:@"score"] length]) {
					[evaluation setObject:[NSNumber numberWithInt:1] forKey:@"eval_done"];
				} else {
					[evaluation setObject:[NSNumber numberWithInt:0] forKey:@"eval_done"];
				}
				FMResultSet *rs = [db executeQuery:@"SELECT * FROM evaluation WHERE guid = ?", guid];
				if (rs && [rs next]) {
					if ([[evaluation objectForKey:@"score"] length] == 0) {
						[evaluation setObject:[rs stringForColumn:@"score"] forKey:@"score"];
						[evaluation setObject:[rs stringForColumn:@"score_max"] forKey:@"score_max"];
					}
					if ([rs intForColumn:@"eval_done"] == 1) {
						[evaluation setObject:[NSNumber numberWithInt:1] forKey:@"eval_done"];
					}
					[rs close];					
				}
			}
		}
	}

//	NSSortDescriptor *sortDescriptor = [[[NSSortDescriptor alloc] initWithKey:@"ordre"
//																																	ascending:YES
//																																	 selector:@selector(compareWithNumericSearch:)] autorelease];
//	
//	NSArray *descriptors = [NSArray arrayWithObjects:sortDescriptor, nil];
//	
//	NSArray *sortedEvalList = [evalList sortedArrayUsingDescriptors:descriptors];
//	CMLog(@"sorted processedList: %@", sortedEvalList);
//	CMLog(@"processedList: %@", evalList);
	return evalList;
}

//==========================================================================================
- (NSData *) loadDataFromURL:(NSString *)dataURL
{
	DataDownloader *downloader = NULL;

	if (!dataURL)
		return NULL;
	
	CMLog(@"URL:%@", dataURL);
	START_TIMER;
	downloader = [[DataDownloader alloc] initWithDataURL:dataURL];
	NSError *error = nil;
	NSData *receivedData = [downloader downloadWithErrorHandle:&error];
	END_TIMER(@"loadDataFromURL");
	if (error != nil) {
		[downloader release];
		//		CMLog(@"error: %@", error);
		return nil;
	}
	
	NSData *data = [NSData dataWithData:receivedData];
	[downloader release];
	return data;
}

//==========================================================================================
- (BOOL) extractZipFile:(NSString *)zipfilename toFolder:(NSString *)folder
{
	MARK;
	BOOL result = TRUE;
	NSString *destPath = [self.documentsPath stringByAppendingPathComponent:folder];
	[[NSFileManager defaultManager] removeItemAtPath:destPath error:nil];
	if (![[NSFileManager defaultManager] createDirectoryAtPath:destPath attributes:nil]) {
		CMLog(@"Failed to create dest folder: %@", destPath);
		return FALSE;
	}
	
	CMLog(@"zipfilename: %@", zipfilename);
	FFArchiveZIP *arch = [[FFArchiveZIP alloc] initWithFile:zipfilename fallbackEncoding:NSUTF8StringEncoding];
	@try {
		NSError *theError = nil;
		NSArray *files = [arch filesInArchive:&theError];
		for (NSDictionary *filedata in files) {
			NSString *filename = [filedata objectForKey:@"ff_filename"];
			NSError *theError = nil;
			NSMutableArray *components = [NSMutableArray arrayWithArray:[filename pathComponents]];
			if ([components count] > 1) {
				[components removeLastObject];
				NSString *newPath = [NSString stringWithFormat:@"%@/%@", destPath, [NSString pathWithComponents:components]];
				[[NSFileManager defaultManager] createDirectoryAtPath:newPath withIntermediateDirectories:TRUE attributes:nil error:&theError];
				if (theError) {
					NSException *e = [NSException
														exceptionWithName:@"Cant create dir"
														reason:@""
														userInfo:nil];
					@throw e;
				}
			}
			[arch extractFile:filename toFilePath:[NSString stringWithFormat:@"%@/%@", destPath, filename] error:&theError];
			if (theError) {
				NSException *e = [NSException
													exceptionWithName:@"Cant extract file"
													reason:@""
													userInfo:nil];
				@throw e;
			}
			CMLog(@"Found file: %@", filedata);
		}
	}
	@catch ( id exception ) {
		result = FALSE;
		CMLog(@"Failed Zip!: %@", exception);
	}
	@finally {
		[arch release]; 
	}
	if (result == FALSE) {
		[[NSFileManager defaultManager] removeItemAtPath:destPath error:nil];
	}
	return result;
}

@end
