//
//  MainViewController.h
//  onlineformapro
//
//  Created by Stephan on 02.03.09.
//  Copyright 2009 Coriolis Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SFHFHUDView.h"


@interface MainViewController : UIViewController {

	IBOutlet UIButton *beginButton;
	IBOutlet UIButton *optionButton;
	IBOutlet UIButton *helpButton;
	IBOutlet UILabel *versionLabel;
	SFHFHUDView *hudWindow;

//	UINavigationController *navigationController;
}

- (IBAction) start:(id)sender;
- (IBAction) showOptions:(id)sender;
- (IBAction) showHelp:(id)sender;

@property (nonatomic, retain) UIButton *beginButton;
@property (nonatomic, retain) UIButton *optionButton;
@property (nonatomic, retain) UIButton *helpButton;
@property (nonatomic, retain) UILabel *versionLabel;
//@property (nonatomic, retain) IBOutlet UINavigationController *navigationController;

@end
