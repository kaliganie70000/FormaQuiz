//
//  DescriptifEvalViewController.m
//  onlineformapro
//
//  Created by Stephan on 05.03.09.
//  Copyright 2009 Coriolis Technologies. All rights reserved.
//

#import "DescriptifEvalViewController.h"
#import "onlineformaproAppDelegate.h"
#import "QuestionViewController.h"
#import "ofpAppDelegate_XMLStuff.h"
#import "Reachability.h"


@implementation DescriptifEvalViewController

@synthesize button;
@synthesize buttonImage;
@synthesize evalNameLabel;
@synthesize sousThemeLabel;
@synthesize descriptifLabel;
@synthesize scoreLabel;
@synthesize trashButtonItem;
@synthesize evaluation;
@synthesize themeTitle;
@synthesize sousThemeTitle;
@synthesize loadingView;
@synthesize activityIndicator;
@synthesize loadingViewLabel;

//==========================================================================================
- (void)viewDidLoad
{
	[super viewDidLoad];
}

//==========================================================================================
- (void) viewWillAppear:(BOOL) animated
{
	loadingView.hidden = YES;
	self.title = self.themeTitle;
#if DEBUG==1
//	[evaluation setObject:@"" forKey:@"score"];
#endif
	if ([[evaluation objectForKey:@"score"] length]) {
		self.scoreLabel.text = [NSString stringWithFormat:@"Score : %d/%d", [[evaluation objectForKey:@"score"] intValue],[[evaluation objectForKey:@"scoremax"] intValue]];
		self.scoreLabel.hidden = FALSE;
		self.button.hidden = TRUE;
		self.buttonImage.hidden = TRUE;
	} else {
		self.scoreLabel.hidden = TRUE;
		self.scoreLabel.text = @""; 
		self.button.hidden = FALSE;
		self.buttonImage.hidden = FALSE;
	}
	self.sousThemeLabel.text = self.sousThemeTitle;
	self.evalNameLabel.text = [evaluation objectForKey:@"titre"];
	self.descriptifLabel.text = [evaluation objectForKey:@"description"];
	
	if ([[evaluation objectForKey:@"eval_downloaded"] intValue] == 1) {
		[self.trashButtonItem setEnabled:YES];
		[self.button setTitle:@"Commencer" forState:UIControlStateNormal];
		[self.button setTitle:@"Commencer" forState:UIControlStateHighlighted];
	} else {
		[self.trashButtonItem setEnabled:NO];
		[self.button setTitle:@"Télécharger" forState:UIControlStateNormal];
		[self.button setTitle:@"Télécharger" forState:UIControlStateHighlighted];
	}
}

//==========================================================================================
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
	// Return YES for supported orientations
	return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

//==========================================================================================
- (void)didReceiveMemoryWarning
{
	[super didReceiveMemoryWarning]; // Releases the view if it doesn't have a superview
	// Release anything that's not essential, such as cached data
}

//==========================================================================================
- (void)dealloc
{
	[buttonImage release];
	[scoreLabel release];
	[loadingView release];
	[activityIndicator release];
	[loadingViewLabel release];
	[button release];
	[evalNameLabel release];
	[sousThemeLabel release];
	[descriptifLabel release];
	[trashButtonItem release];
	[evaluation release];
	[super dealloc];
}

//==========================================================================================
- (IBAction) trashItem:(id)sender
{
	NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
	NSString *documentsDirectory = [paths objectAtIndex:0];
	NSString *guid = [evaluation objectForKey:@"guid"];
	NSString *evalPath = [NSString stringWithFormat:@"%@/%@", documentsDirectory, guid];
	[[NSFileManager defaultManager] removeItemAtPath:evalPath error:nil];
	[self.trashButtonItem setEnabled:NO];
	[self.button setTitle:@"Télécharger" forState:UIControlStateNormal];
	[self.button setTitle:@"Télécharger" forState:UIControlStateHighlighted];
	[evaluation setObject:[NSNumber numberWithInt:0] forKey:@"eval_downloaded"];
	[evaluation setObject:[NSNumber numberWithInt:0] forKey:@"eval_done"];
	FMDatabase *db = [[OFPDatabase sharedInstance] ofp_DB];
	[db executeUpdate :@"DELETE FROM evaluation WHERE guid = ?", guid];
	[db executeUpdate :@"DELETE FROM resultats WHERE guid = ?", guid];
}

//==========================================================================================
- (IBAction) buttonAction:(id)sender
{
	if ([[evaluation objectForKey:@"eval_downloaded"] intValue] == 1) {
		NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
		NSString *documentsDirectory = [paths objectAtIndex:0];
		NSString *guid = [evaluation objectForKey:@"guid"];
		NSString *evalPath = [NSString stringWithFormat:@"%@/%@", documentsDirectory, guid];
		NSArray *questionListArray = [UIAppDelegate questionsListForGUID:guid];
		QuestionViewController *viewController = [[QuestionViewController alloc] initWithNibName:@"QuestionViewController" bundle:nil];
		viewController.evalPath = evalPath;
		viewController.evalGUID = guid;
		viewController.questionLabel.text = @"";
		viewController.questionListArray = questionListArray;
		viewController.timeLimit = [[evaluation objectForKey:@"duree"] intValue];
		viewController.scoreMax = [[evaluation objectForKey:@"score_max"] intValue];
		
		[UIView beginAnimations:nil context:NULL];
		[UIView setAnimationDuration: 0.5f];
		[self.navigationController pushViewController:viewController animated:NO];
		[UIView setAnimationTransition:UIViewAnimationTransitionFlipFromLeft forView:self.navigationController.view cache:NO];
		[viewController performSelector:@selector(displayNextQuestion) withObject:nil afterDelay:0.2f];
		[UIView commitAnimations];
		[viewController release];
	} else {
		NetworkStatus remoteHostStatus         = [[Reachability sharedReachability] remoteHostStatus];
		NetworkStatus internetConnectionStatus = [[Reachability sharedReachability] internetConnectionStatus];
		
		//	CMLog(@"internetConnectionStatus: %d, remoteHostStatus: %d", internetConnectionStatus, remoteHostStatus);
		
		if ((internetConnectionStatus == NotReachable) && (remoteHostStatus == NotReachable)) {
			UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Attention" message:@"Vous devez avoir une connexion internet pour pouvoir effectuer un téléchargement." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
			[alert show];
			[alert release];	
		} else {
			loadingView.hidden = FALSE;
			loadingViewLabel.text = @"Téléchargement de l'évaluation";
			[self performSelector:@selector(downloadEval) withObject:nil afterDelay:0.2f];
		}
	}
}

//==========================================================================================
- (void) downloadEval
{
	NSData *data = [UIAppDelegate loadDataFromURL:[evaluation objectForKey:@"chemin"]];
	if (data != NULL) {
		NSString *destPath = [NSString stringWithFormat:@"%@/temp.zip", NSTemporaryDirectory()];
		[[NSFileManager defaultManager] removeItemAtPath:destPath error:nil];
		loadingViewLabel.text = @"Désarchivage de l'évaluation";
		if ([data writeToFile:destPath atomically:YES]) {
			if ([UIAppDelegate extractZipFile:destPath toFolder:[evaluation objectForKey:@"guid"]]) {
				[evaluation setObject:[NSNumber numberWithInt:1] forKey:@"eval_downloaded"];
				[self.trashButtonItem setEnabled:YES];
				[self.button setTitle:@"Commencer" forState:UIControlStateNormal];
				[self.button setTitle:@"Commencer" forState:UIControlStateHighlighted];
			}else {
				UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Attention" message:@"L'évaluation n'a pu être désarchivée." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
				[alert show];
				[alert release];	
			}
		}
		[[NSFileManager defaultManager] removeItemAtPath:destPath error:nil];
	}
	loadingView.hidden = YES;
}

@end
