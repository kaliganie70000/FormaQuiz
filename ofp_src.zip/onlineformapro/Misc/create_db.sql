CREATE TABLE evaluation (guid TEXT,dureesuivi INTEGER,score INTEGER, eval_done INTEGER);
CREATE TABLE dbinfo (version INTEGER);
CREATE TABLE resultats (guid TEXT,data TEXT);
