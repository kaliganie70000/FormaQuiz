//
//  LiaisonsAppDelegate.m
//  Liaisons
//
//  Created by Stephan on 09.03.09.
//  Copyright Coriolis Technologies 2009. All rights reserved.
//

#import "LiaisonsAppDelegate.h"
#import "Liaisons_QuestionViewController.h"

@implementation LiaisonsAppDelegate

@synthesize window;


- (void)applicationDidFinishLaunching:(UIApplication *)application {    

	NSMutableDictionary *dict = [NSMutableDictionary dictionary];
	Liaisons_QuestionViewController *viewController = [[Liaisons_QuestionViewController alloc] initWithNibName:@"Liaisons_QuestionViewController" bundle:nil];
	[dict setObject:@"Word*^*Excel*^*Photoshop*^*Audacity*^**^**^**^*Tableur*^*Boite à rythme et séquenceur*^*Boite à rythme et séquenceur*^*Traitement d'image*^**^**^*" forKey:@"propositions"];
	[dict setObject:@"G0_D1*^*G1_D0*^*G2_D3*^*G3_D2" forKey:@"solutions"];
	viewController.question = dict;
	CGRect frame = viewController.view.frame;
	frame.origin.y = 112.0f;
	viewController.view.frame = frame;
	[window addSubview:viewController.view];
//	[viewController release];
    // Override point for customization after application launch
  [window makeKeyAndVisible];
}


- (void)dealloc {
    [window release];
    [super dealloc];
}


@end
