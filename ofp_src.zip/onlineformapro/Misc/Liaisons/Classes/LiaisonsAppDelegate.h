//
//  LiaisonsAppDelegate.h
//  Liaisons
//
//  Created by Stephan on 09.03.09.
//  Copyright Coriolis Technologies 2009. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LiaisonsAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end

